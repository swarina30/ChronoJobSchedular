#!/bin/bash

# Comprehensive Test Script for Job Scheduler
# Tests all services, endpoints, and scenarios

set -e

API_URL="http://localhost:5136"
MONITOR_URL="http://localhost:5208"

echo "=========================================="
echo "  Job Scheduler - Comprehensive Test"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counter
PASSED=0
FAILED=0

test_result() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ PASSED${NC}: $1"
        ((PASSED++))
    else
        echo -e "${RED}✗ FAILED${NC}: $1"
        ((FAILED++))
    fi
}

echo "Step 1: Checking Infrastructure..."
echo "-----------------------------------"
docker-compose ps | grep -q "Up" && echo -e "${GREEN}✓${NC} MySQL and Redis are running" || echo -e "${RED}✗${NC} Infrastructure not running"
echo ""

echo "Step 2: Testing User Signup (3 Users)..."
echo "----------------------------------------"
# User 1
USER1_RESPONSE=$(curl -s -X POST "$API_URL/api/auth/signup" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice",
    "email": "alice@example.com",
    "password": "password123"
  }')
USER1_TOKEN=$(echo $USER1_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)
USER1_ID=$(echo $USER1_RESPONSE | grep -o '"userId":"[^"]*' | cut -d'"' -f4)
[ -n "$USER1_TOKEN" ] && test_result "User 1 (alice) signup" || echo -e "${RED}✗${NC} User 1 signup failed"
echo "  User 1 ID: $USER1_ID"
echo ""

# User 2
USER2_RESPONSE=$(curl -s -X POST "$API_URL/api/auth/signup" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "bob",
    "email": "bob@example.com",
    "password": "password123"
  }')
USER2_TOKEN=$(echo $USER2_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)
USER2_ID=$(echo $USER2_RESPONSE | grep -o '"userId":"[^"]*' | cut -d'"' -f4)
[ -n "$USER2_TOKEN" ] && test_result "User 2 (bob) signup" || echo -e "${RED}✗${NC} User 2 signup failed"
echo "  User 2 ID: $USER2_ID"
echo ""

# User 3
USER3_RESPONSE=$(curl -s -X POST "$API_URL/api/auth/signup" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "charlie",
    "email": "charlie@example.com",
    "password": "password123"
  }')
USER3_TOKEN=$(echo $USER3_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)
USER3_ID=$(echo $USER3_RESPONSE | grep -o '"userId":"[^"]*' | cut -d'"' -f4)
[ -n "$USER3_TOKEN" ] && test_result "User 3 (charlie) signup" || echo -e "${RED}✗${NC} User 3 signup failed"
echo "  User 3 ID: $USER3_ID"
echo ""

echo "Step 3: Testing Login..."
echo "----------------------"
LOGIN_RESPONSE=$(curl -s -X POST "$API_URL/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "alice@example.com",
    "password": "password123"
  }')
LOGIN_TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)
[ -n "$LOGIN_TOKEN" ] && test_result "Login with credentials" || echo -e "${RED}✗${NC} Login failed"
echo ""

echo "Step 4: Testing Job Creation (One-Time Jobs)..."
echo "-----------------------------------------------"
# User 1 - One-time job
JOB1_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs" \
  -H "Authorization: Bearer $USER1_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "jobType": "OneTime",
    "scriptContent": "print(\"Hello from Alice!\")",
    "scheduledAt": "'$(date -u -v+2M +"%Y-%m-%dT%H:%M:%SZ")'",
    "timeoutSeconds": 60,
    "retryPolicy": {
      "maxAttempts": 3,
      "strategy": "ExponentialBackoff",
      "initialDelaySeconds": 5,
      "maxDelaySeconds": 300,
      "multiplier": 2.0
    }
  }')
JOB1_ID=$(echo $JOB1_RESPONSE | grep -o '"jobId":"[^"]*' | cut -d'"' -f4)
[ -n "$JOB1_ID" ] && test_result "User 1 - One-time job creation" || echo -e "${RED}✗${NC} Job 1 creation failed"
echo "  Job 1 ID: $JOB1_ID"
echo ""

# User 2 - One-time job
JOB2_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs" \
  -H "Authorization: Bearer $USER2_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "jobType": "OneTime",
    "scriptContent": "print(\"Hello from Bob!\")",
    "scheduledAt": "'$(date -u -v+3M +"%Y-%m-%dT%H:%M:%SZ")'",
    "timeoutSeconds": 60
  }')
JOB2_ID=$(echo $JOB2_RESPONSE | grep -o '"jobId":"[^"]*' | cut -d'"' -f4)
[ -n "$JOB2_ID" ] && test_result "User 2 - One-time job creation" || echo -e "${RED}✗${NC} Job 2 creation failed"
echo "  Job 2 ID: $JOB2_ID"
echo ""

# User 3 - One-time job (immediate)
JOB3_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs" \
  -H "Authorization: Bearer $USER3_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "jobType": "OneTime",
    "scriptContent": "print(\"Hello from Charlie!\")",
    "timeoutSeconds": 60
  }')
JOB3_ID=$(echo $JOB3_RESPONSE | grep -o '"jobId":"[^"]*' | cut -d'"' -f4)
[ -n "$JOB3_ID" ] && test_result "User 3 - One-time job (immediate)" || echo -e "${RED}✗${NC} Job 3 creation failed"
echo "  Job 3 ID: $JOB3_ID"
echo ""

echo "Step 5: Testing Recurring Job Creation..."
echo "------------------------------------------"
# User 1 - Recurring job (every 2 minutes)
JOB4_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs" \
  -H "Authorization: Bearer $USER1_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "jobType": "Recurring",
    "cronExpr": "*/2 * * * *",
    "scriptContent": "print(\"Recurring job from Alice!\")",
    "timeoutSeconds": 60,
    "retryPolicy": {
      "maxAttempts": 2,
      "strategy": "LinearBackoff",
      "initialDelaySeconds": 10,
      "maxDelaySeconds": 60
    }
  }')
JOB4_ID=$(echo $JOB4_RESPONSE | grep -o '"jobId":"[^"]*' | cut -d'"' -f4)
[ -n "$JOB4_ID" ] && test_result "User 1 - Recurring job creation" || echo -e "${RED}✗${NC} Job 4 creation failed"
echo "  Job 4 ID: $JOB4_ID"
echo ""

# User 2 - Recurring job (every 5 minutes)
JOB5_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs" \
  -H "Authorization: Bearer $USER2_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "jobType": "Recurring",
    "cronExpr": "*/5 * * * *",
    "scriptContent": "print(\"Recurring job from Bob!\")",
    "timeoutSeconds": 60
  }')
JOB5_ID=$(echo $JOB5_RESPONSE | grep -o '"jobId":"[^"]*' | cut -d'"' -f4)
[ -n "$JOB5_ID" ] && test_result "User 2 - Recurring job creation" || echo -e "${RED}✗${NC} Job 5 creation failed"
echo "  Job 5 ID: $JOB5_ID"
echo ""

echo "Step 6: Testing Get Jobs Endpoint..."
echo "-------------------------------------"
JOBS_RESPONSE=$(curl -s -X GET "$API_URL/api/jobs?page=1&pageSize=10" \
  -H "Authorization: Bearer $USER1_TOKEN")
[ $? -eq 0 ] && test_result "Get jobs for User 1" || echo -e "${RED}✗${NC} Get jobs failed"
echo ""

echo "Step 7: Testing Get Job By ID..."
echo "---------------------------------"
JOB_DETAIL=$(curl -s -X GET "$API_URL/api/jobs/$JOB1_ID" \
  -H "Authorization: Bearer $USER1_TOKEN")
[ $? -eq 0 ] && test_result "Get job by ID" || echo -e "${RED}✗${NC} Get job by ID failed"
echo ""

echo "Step 8: Testing Job Update..."
echo "------------------------------"
UPDATE_RESPONSE=$(curl -s -X PUT "$API_URL/api/jobs/$JOB4_ID" \
  -H "Authorization: Bearer $USER1_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "scriptContent": "print(\"Updated recurring job!\")",
    "version": 1
  }')
[ $? -eq 0 ] && test_result "Update job" || echo -e "${RED}✗${NC} Update job failed"
echo ""

echo "Step 9: Testing Cron Update (should cancel pending runs)..."
echo "----------------------------------------------------------"
CRON_UPDATE_RESPONSE=$(curl -s -X PUT "$API_URL/api/jobs/$JOB4_ID" \
  -H "Authorization: Bearer $USER1_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "cronExpr": "*/10 * * * *",
    "version": 2
  }')
[ $? -eq 0 ] && test_result "Update cron expression" || echo -e "${RED}✗${NC} Cron update failed"
echo ""

echo "Step 10: Testing Pause Job..."
echo "------------------------------"
PAUSE_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs/$JOB5_ID/pause" \
  -H "Authorization: Bearer $USER2_TOKEN")
[ $? -eq 0 ] && test_result "Pause job" || echo -e "${RED}✗${NC} Pause job failed"
echo ""

echo "Step 11: Testing Resume Job..."
echo "-------------------------------"
RESUME_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs/$JOB5_ID/resume" \
  -H "Authorization: Bearer $USER2_TOKEN")
[ $? -eq 0 ] && test_result "Resume job" || echo -e "${RED}✗${NC} Resume job failed"
echo ""

echo "Step 12: Testing Get Job Runs..."
echo "---------------------------------"
RUNS_RESPONSE=$(curl -s -X GET "$API_URL/api/jobs/$JOB1_ID/runs?page=1&pageSize=10" \
  -H "Authorization: Bearer $USER1_TOKEN")
[ $? -eq 0 ] && test_result "Get job runs" || echo -e "${RED}✗${NC} Get job runs failed"
echo ""

echo "Step 13: Testing Health Monitoring..."
echo "--------------------------------------"
HEALTH_RESPONSE=$(curl -s -X GET "$MONITOR_URL/api/health")
[ $? -eq 0 ] && test_result "Health check endpoint" || echo -e "${RED}✗${NC} Health check failed"
echo ""

METRICS_RESPONSE=$(curl -s -X GET "$MONITOR_URL/api/health/metrics")
[ $? -eq 0 ] && test_result "Health metrics endpoint" || echo -e "${RED}✗${NC} Health metrics failed"
echo ""

echo "Step 14: Testing Ownership (User 2 cannot access User 1 job)..."
echo "-----------------------------------------------------------------"
UNAUTHORIZED_RESPONSE=$(curl -s -w "%{http_code}" -X GET "$API_URL/api/jobs/$JOB1_ID" \
  -H "Authorization: Bearer $USER2_TOKEN" -o /dev/null)
[ "$UNAUTHORIZED_RESPONSE" = "403" ] && test_result "Ownership check (403 Forbidden)" || echo -e "${RED}✗${NC} Ownership check failed (got $UNAUTHORIZED_RESPONSE)"
echo ""

echo "Step 15: Testing Delete Job..."
echo "-------------------------------"
DELETE_RESPONSE=$(curl -s -X DELETE "$API_URL/api/jobs/$JOB3_ID" \
  -H "Authorization: Bearer $USER3_TOKEN")
[ $? -eq 0 ] && test_result "Delete job" || echo -e "${RED}✗${NC} Delete job failed"
echo ""

echo "Step 16: Waiting 30 seconds for jobs to execute..."
echo "---------------------------------------------------"
sleep 30
echo ""

echo "Step 17: Checking Job Run Status..."
echo "------------------------------------"
RUNS_AFTER_EXEC=$(curl -s -X GET "$API_URL/api/jobs/$JOB3_ID/runs?page=1&pageSize=10" \
  -H "Authorization: Bearer $USER3_TOKEN")
[ $? -eq 0 ] && test_result "Check job runs after execution" || echo -e "${RED}✗${NC} Check runs failed"
echo ""

echo "=========================================="
echo "  Test Summary"
echo "=========================================="
echo -e "${GREEN}Passed: $PASSED${NC}"
echo -e "${RED}Failed: $FAILED${NC}"
echo ""

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}All tests passed! ✓${NC}"
    exit 0
else
    echo -e "${RED}Some tests failed! ✗${NC}"
    exit 1
fi
