#!/bin/bash

# Script to monitor all three services
# Usage: ./MONITOR_SERVICES.sh

echo "=== Job Scheduler - Service Monitor ==="
echo ""

# Check if services are running
API_COUNT=$(ps aux | grep -c "dotnet.*Job\.Api" | grep -v grep || echo "0")
SCHEDULER_COUNT=$(ps aux | grep -c "dotnet.*Job\.Scheduler" | grep -v grep || echo "0")
WORKER_COUNT=$(ps aux | grep -c "dotnet.*Job\.Worker" | grep -v grep || echo "0")

echo "Service Status:"
echo "  API:      $([ $API_COUNT -gt 0 ] && echo "✅ Running" || echo "❌ Stopped")"
echo "  Scheduler: $([ $SCHEDULER_COUNT -gt 0 ] && echo "✅ Running" || echo "❌ Stopped")"
echo "  Worker:   $([ $WORKER_COUNT -gt 0 ] && echo "✅ Running" || echo "❌ Stopped")"
echo ""

# Show recent logs
echo "=== API Service (last 5 lines) ==="
tail -5 /tmp/job-api.log 2>/dev/null || echo "No logs found"
echo ""

echo "=== Scheduler Service (last 5 lines) ==="
tail -5 /tmp/job-scheduler.log 2>/dev/null || echo "No logs found"
echo ""

echo "=== Worker Service (last 5 lines) ==="
tail -5 /tmp/job-worker.log 2>/dev/null || echo "No logs found"
echo ""

# Check database
echo "=== Database - Pending Jobs ==="
docker exec job-scheduler-mysql mysql -u root -proot job_scheduler_dev -e "
SELECT COUNT(*) as pending_count 
FROM job_run 
WHERE status = 'PENDING' 
AND scheduled_at <= UTC_TIMESTAMP();" 2>/dev/null || echo "Cannot connect to database"
echo ""

echo "=== Redis Queues ==="
for i in {0..3}; do
    COUNT=$(docker exec job-scheduler-redis redis-cli LLEN "queue:$i" 2>/dev/null || echo "0")
    echo "  queue:$i = $COUNT items"
done
