-- job_definition and job_schedule_state (migration creates job_run)
USE job_scheduler_dev;

CREATE TABLE IF NOT EXISTS job_definition (
    job_id CHAR(36) NOT NULL PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    created_by CHAR(36) NOT NULL,
    updated_by CHAR(36) NULL,
    job_type VARCHAR(20) NOT NULL,
    cron_expr VARCHAR(255) NULL,
    script_content LONGTEXT NOT NULL,
    args_json JSON NULL,
    retry_policy_json JSON NULL,
    timeout_seconds INT NULL,
    status VARCHAR(20) NOT NULL,
    server_id VARCHAR(100) NULL,
    version INT NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at DATETIME(6) NULL,
    last_replicated_at DATETIME(6) NULL,
    replication_version BIGINT NULL,
    INDEX idx_job_definition_user (user_id),
    INDEX idx_job_definition_status (status),
    INDEX idx_job_definition_created_at (created_at)
);

CREATE TABLE IF NOT EXISTS job_schedule_state (
    job_id CHAR(36) NOT NULL PRIMARY KEY,
    last_scheduled_at DATETIME(6) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    next_run_at DATETIME(6) NULL,
    scheduler_id VARCHAR(100) NULL,
    version INT NOT NULL DEFAULT 1,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    last_replicated_at DATETIME(6) NULL,
    replication_version BIGINT NULL,
    INDEX idx_schedule_active (is_active),
    INDEX idx_schedule_next_run (next_run_at)
);
