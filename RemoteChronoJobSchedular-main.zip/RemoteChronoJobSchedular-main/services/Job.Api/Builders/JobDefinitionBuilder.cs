using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Models;
using System.Text.Json;

namespace Job.Api.Builders;

/// <summary>
/// Builder pattern for creating JobDefinition entities (fluent API)
/// </summary>
public class JobDefinitionBuilder
{
    private readonly JobDefinition _job = new();

    private JobDefinitionBuilder(Guid userId, Guid createdBy)
    {
        _job.JobId = Guid.NewGuid();
        _job.UserId = userId;
        _job.CreatedBy = createdBy;
        _job.Status = JobStatus.Created;
        _job.CreatedAt = DateTime.UtcNow;
        _job.UpdatedAt = DateTime.UtcNow;
    }

    /// <summary>
    /// Create a new builder instance
    /// </summary>
    public static JobDefinitionBuilder Create(Guid userId, Guid createdBy)
    {
        return new JobDefinitionBuilder(userId, createdBy);
    }

    /// <summary>
    /// Set job type
    /// </summary>
    public JobDefinitionBuilder WithType(JobType jobType)
    {
        _job.JobType = jobType;
        return this;
    }

    /// <summary>
    /// Set cron expression (for recurring jobs)
    /// </summary>
    public JobDefinitionBuilder WithCron(string cronExpr)
    {
        if (_job.JobType != JobType.Recurring)
        {
            throw new InvalidOperationException("Cron expression can only be set for recurring jobs");
        }
        _job.CronExpr = cronExpr;
        return this;
    }

    /// <summary>
    /// Set Python script content
    /// </summary>
    public JobDefinitionBuilder WithScriptContent(string scriptContent)
    {
        if (string.IsNullOrWhiteSpace(scriptContent))
        {
            throw new ArgumentException("Script content cannot be null or empty", nameof(scriptContent));
        }
        _job.ScriptContent = scriptContent;
        return this;
    }

    /// <summary>
    /// Set script arguments (serialized to JSON)
    /// </summary>
    public JobDefinitionBuilder WithArguments(Dictionary<string, object>? args)
    {
        _job.ArgsJson = args != null ? JsonSerializer.Serialize(args) : null;
        return this;
    }

    /// <summary>
    /// Set retry policy
    /// </summary>
    public JobDefinitionBuilder WithRetryPolicy(RetryPolicy policy)
    {
        _job.RetryPolicyJson = JsonSerializer.Serialize(policy);
        return this;
    }

    /// <summary>
    /// Set timeout in seconds
    /// </summary>
    public JobDefinitionBuilder WithTimeout(int timeoutSeconds)
    {
        if (timeoutSeconds < 1)
        {
            throw new ArgumentException("Timeout must be at least 1 second", nameof(timeoutSeconds));
        }
        _job.TimeoutSeconds = timeoutSeconds;
        return this;
    }

    /// <summary>
    /// Set server ID (for multi-instance tracking)
    /// </summary>
    public JobDefinitionBuilder WithServerId(string? serverId)
    {
        _job.ServerId = serverId;
        return this;
    }

    /// <summary>
    /// Set status (default: Created)
    /// </summary>
    public JobDefinitionBuilder WithStatus(JobStatus status)
    {
        _job.Status = status;
        return this;
    }

    /// <summary>
    /// Build the JobDefinition entity
    /// </summary>
    public JobDefinition Build()
    {
        // Validation
        if (string.IsNullOrWhiteSpace(_job.ScriptContent))
        {
            throw new InvalidOperationException("Script content is required");
        }

        if (_job.JobType == JobType.Recurring && string.IsNullOrWhiteSpace(_job.CronExpr))
        {
            throw new InvalidOperationException("Cron expression is required for recurring jobs");
        }

        if (_job.JobType == JobType.OneTime && !string.IsNullOrWhiteSpace(_job.CronExpr))
        {
            throw new InvalidOperationException("Cron expression should not be set for one-time jobs");
        }

        return _job;
    }
}
