using Job.Api.Models.Requests;
using Job.Api.Models.Responses;
using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Infrastructure.Auth;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Job.Api.Controllers;

/// <summary>
/// Authentication controller
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly JwtTokenService _tokenService;
    private readonly IUserRepository _userRepository;
    private readonly ILogger<AuthController> _logger;

    public AuthController(
        JwtTokenService tokenService, 
        IUserRepository userRepository,
        ILogger<AuthController> logger)
    {
        _tokenService = tokenService;
        _userRepository = userRepository;
        _logger = logger;
    }

    /// <summary>
    /// Sign up a new user
    /// </summary>
    [HttpPost("signup")]
    public async Task<IActionResult> Signup([FromBody] SignupRequest request, CancellationToken ct = default)
    {
        _logger.LogInformation("Signup attempt for email: {Email}, username: {Username}", request.Email, request.Username);

        // Check if email already exists
        if (await _userRepository.EmailExistsAsync(request.Email, ct))
        {
            _logger.LogWarning("Signup failed: Email {Email} already exists", request.Email);
            return Conflict(new { error = "Email already registered" });
        }

        // Check if username already exists
        if (await _userRepository.UsernameExistsAsync(request.Username, ct))
        {
            _logger.LogWarning("Signup failed: Username {Username} already exists", request.Username);
            return Conflict(new { error = "Username already taken" });
        }

        // Hash password
        var passwordHash = PasswordHasher.HashPassword(request.Password);

        // Create user
        var user = new User
        {
            UserId = Guid.NewGuid(),
            Username = request.Username,
            Email = request.Email,
            PasswordHash = passwordHash,
            Role = UserRole.User, // Default role
            IsActive = true,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        try
        {
            var createdUser = await _userRepository.CreateAsync(user, ct);
            
            _logger.LogInformation("User signed up successfully: {UserId}, email: {Email}", 
                createdUser.UserId, createdUser.Email);

            // Generate token for immediate login
            var token = _tokenService.GenerateToken(createdUser.UserId, createdUser.Email, createdUser.Role);

            return CreatedAtAction(nameof(Login), new { }, new LoginResponse
            {
                Token = token,
                UserId = createdUser.UserId,
                Email = createdUser.Email,
                Role = createdUser.Role.ToString()
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating user during signup");
            return StatusCode(500, new { error = "Failed to create user account" });
        }
    }

    /// <summary>
    /// Login endpoint (generates JWT token)
    /// </summary>
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken ct = default)
    {
        _logger.LogInformation("Login attempt for email: {Email}", request.Email);

        // Validate credentials against database
        var user = await _userRepository.GetByEmailAsync(request.Email, ct);
        
        if (user == null)
        {
            _logger.LogWarning("Login failed: User with email {Email} not found", request.Email);
            return Unauthorized(new { error = "Invalid email or password" });
        }

        if (!PasswordHasher.VerifyPassword(request.Password, user.PasswordHash))
        {
            _logger.LogWarning("Login failed: Invalid password for user {UserId}", user.UserId);
            return Unauthorized(new { error = "Invalid email or password" });
        }

        if (!user.IsActive)
        {
            _logger.LogWarning("Login failed: User {UserId} is inactive", user.UserId);
            return Forbid("Account is inactive");
        }

        // Update last login time
        await _userRepository.UpdateLastLoginAsync(user.UserId, ct);

        // Generate token
        var token = _tokenService.GenerateToken(user.UserId, user.Email, user.Role);

        _logger.LogInformation("Login successful for user: {UserId}, email: {Email}", user.UserId, user.Email);

        return Ok(new LoginResponse
        {
            Token = token,
            UserId = user.UserId,
            Email = user.Email,
            Role = user.Role.ToString()
        });
    }
}

/// <summary>
/// Login request model
/// </summary>
public class LoginRequest
{
    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;
    
    [Required]
    public string Password { get; set; } = string.Empty;
}

/// <summary>
/// Login response model
/// </summary>
public class LoginResponse
{
    public string Token { get; set; } = string.Empty;
    public Guid UserId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}
