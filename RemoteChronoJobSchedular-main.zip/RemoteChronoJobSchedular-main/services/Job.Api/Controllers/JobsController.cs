using Job.Api.Models.Requests;
using Job.Api.Models.Responses;
using Job.Api.Services;
using JobScheduler.Infrastructure.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

namespace Job.Api.Controllers;

/// <summary>
/// Jobs API controller
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize]
public class JobsController : ControllerBase
{
    private readonly IJobService _jobService;
    private readonly ILogger<JobsController> _logger;

    public JobsController(IJobService jobService, ILogger<JobsController> logger)
    {
        _jobService = jobService;
        _logger = logger;
    }

    /// <summary>
    /// Create a new job
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<JobResponse>> CreateJob([FromBody] CreateJobRequest request, CancellationToken ct)
    {
        // Get user ID from claims (will be implemented in auth middleware)
        var userId = GetUserIdFromClaims();
        
        _logger.LogInformation("Creating job for user {UserId}, type: {JobType}", userId, request.JobType);
        
        var job = await _jobService.CreateJobAsync(userId, request, ct);
        var response = MapToResponse(job);
        
        return CreatedAtAction(nameof(GetJob), new { jobId = job.JobId }, response);
    }

    /// <summary>
    /// Get job by ID
    /// </summary>
    [HttpGet("{jobId}")]
    public async Task<ActionResult<JobResponse>> GetJob(Guid jobId, CancellationToken ct)
    {
        var userId = GetUserIdFromClaims();
        
        var job = await _jobService.GetJobByIdAsync(jobId, userId, ct);
        if (job == null)
        {
            return NotFound(new { error = "Job not found", jobId });
        }
        
        return Ok(MapToResponse(job));
    }

    /// <summary>
    /// Update job
    /// </summary>
    [HttpPut("{jobId}")]
    public async Task<ActionResult<JobResponse>> UpdateJob(Guid jobId, [FromBody] UpdateJobRequest request, CancellationToken ct)
    {
        var userId = GetUserIdFromClaims();
        
        _logger.LogInformation("Updating job {JobId} for user {UserId}", jobId, userId);
        
        try
        {
            var job = await _jobService.UpdateJobAsync(jobId, userId, request, ct);
            return Ok(MapToResponse(job));
        }
        catch (UnauthorizedAccessException)
        {
            return Forbid();
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("Version"))
        {
            return Conflict(new { error = "Version conflict - job was modified by another request", jobId });
        }
        catch (KeyNotFoundException)
        {
            return NotFound(new { error = "Job not found", jobId });
        }
    }

    /// <summary>
    /// Delete job (soft delete)
    /// </summary>
    [HttpDelete("{jobId}")]
    public async Task<IActionResult> DeleteJob(Guid jobId, CancellationToken ct)
    {
        var userId = GetUserIdFromClaims();
        
        _logger.LogInformation("Deleting job {JobId} for user {UserId}", jobId, userId);
        
        var deleted = await _jobService.DeleteJobAsync(jobId, userId, ct);
        if (!deleted)
        {
            return NotFound(new { error = "Job not found", jobId });
        }
        
        return NoContent();
    }

    /// <summary>
    /// List jobs for current user
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<PagedResponse<JobResponse>>> ListJobs(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        var userId = GetUserIdFromClaims();
        
        var result = await _jobService.GetJobsByUserIdAsync(userId, page, pageSize, ct);
        var response = new PagedResponse<JobResponse>
        {
            Items = result.Items.Select(MapToResponse).ToList(),
            TotalCount = result.TotalCount,
            Page = result.Page,
            PageSize = result.PageSize,
            TotalPages = result.TotalPages
        };
        
        return Ok(response);
    }

    /// <summary>
    /// Pause recurring job
    /// </summary>
    [HttpPatch("{jobId}/pause")]
    public async Task<ActionResult<JobResponse>> PauseJob(Guid jobId, CancellationToken ct)
    {
        var userId = GetUserIdFromClaims();
        
        _logger.LogInformation("Pausing job {JobId} for user {UserId}", jobId, userId);
        
        var job = await _jobService.PauseJobAsync(jobId, userId, ct);
        if (job == null)
        {
            return NotFound(new { error = "Job not found", jobId });
        }
        
        return Ok(MapToResponse(job));
    }

    /// <summary>
    /// Resume recurring job
    /// </summary>
    [HttpPatch("{jobId}/resume")]
    public async Task<ActionResult<JobResponse>> ResumeJob(Guid jobId, CancellationToken ct)
    {
        var userId = GetUserIdFromClaims();
        
        _logger.LogInformation("Resuming job {JobId} for user {UserId}", jobId, userId);
        
        var job = await _jobService.ResumeJobAsync(jobId, userId, ct);
        if (job == null)
        {
            return NotFound(new { error = "Job not found", jobId });
        }
        
        return Ok(MapToResponse(job));
    }

    /// <summary>
    /// Get job run history for a specific job
    /// </summary>
    [HttpGet("{jobId}/runs")]
    public async Task<ActionResult<PagedResponse<JobRunResponse>>> GetJobRuns(
        Guid jobId,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        var userId = GetUserIdFromClaims();
        
        _logger.LogInformation("Getting job runs for job {JobId}, user {UserId}, page {Page}, pageSize {PageSize}", 
            jobId, userId, page, pageSize);
        
        // Verify job exists and user has access
        var job = await _jobService.GetJobByIdAsync(jobId, userId, ct);
        if (job == null)
        {
            _logger.LogWarning("Job {JobId} not found or access denied for user {UserId}", jobId, userId);
            return NotFound(new { error = "Job not found", jobId });
        }
        
        var runRepository = HttpContext.RequestServices.GetRequiredService<JobScheduler.Contracts.Interfaces.IJobRunRepository>();
        var result = await runRepository.GetRunsByJobIdAsync(jobId, page, pageSize, ct);
        
        _logger.LogInformation("Found {Count} job runs for job {JobId} (total: {Total})", 
            result.Items.Count, jobId, result.TotalCount);
        
        var response = new PagedResponse<JobRunResponse>
        {
            Items = result.Items.Select(MapToRunResponse).ToList(),
            TotalCount = result.TotalCount,
            Page = result.Page,
            PageSize = result.PageSize,
            TotalPages = result.TotalPages
        };
        
        return Ok(response);
    }

    /// <summary>
    /// Get specific job run details
    /// </summary>
    [HttpGet("runs/{runId}")]
    public async Task<ActionResult<JobRunResponse>> GetJobRun(Guid runId, CancellationToken ct)
    {
        var userId = GetUserIdFromClaims();
        
        _logger.LogInformation("Getting job run {RunId} for user {UserId}", runId, userId);
        
        var runRepository = HttpContext.RequestServices.GetRequiredService<JobScheduler.Contracts.Interfaces.IJobRunRepository>();
        var run = await runRepository.GetByIdAsync(runId, ct);
        
        if (run == null)
        {
            _logger.LogWarning("Job run {RunId} not found", runId);
            return NotFound(new { error = "Job run not found", runId });
        }
        
        // Verify user has access to the job
        if (run.Job?.UserId != userId)
        {
            _logger.LogWarning("User {UserId} does not have access to job run {RunId} (job owner: {JobUserId})", 
                userId, runId, run.Job?.UserId);
            return Forbid();
        }
        
        _logger.LogInformation("Job run {RunId} retrieved successfully. Status: {Status}, Attempt: {Attempt}/{MaxRetry}", 
            runId, run.Status, run.Attempt, run.MaxRetry);
        
        return Ok(MapToRunResponse(run));
    }

    // Helper methods
    
    private Guid GetUserIdFromClaims()
    {
        // Extract user ID from JWT token claims
        try
        {
            return JwtTokenService.GetUserIdFromClaims(User);
        }
        catch (UnauthorizedAccessException)
        {
            throw new UnauthorizedAccessException("User ID not found in token claims. Please login again.");
        }
    }

    private static JobResponse MapToResponse(JobScheduler.Contracts.Entities.JobDefinition job)
    {
        var retryPolicy = job.RetryPolicyJson != null
            ? System.Text.Json.JsonSerializer.Deserialize<RetryPolicyResponse>(job.RetryPolicyJson)
            : null;
            
        return new JobResponse
        {
            JobId = job.JobId,
            UserId = job.UserId,
            JobType = job.JobType,
            CronExpr = job.CronExpr,
            Status = job.Status,
            TimeoutSeconds = job.TimeoutSeconds,
            RetryPolicy = retryPolicy,
            CreatedAt = job.CreatedAt,
            UpdatedAt = job.UpdatedAt,
            Version = job.Version
        };
    }

    private static JobRunResponse MapToRunResponse(JobScheduler.Contracts.Entities.JobRun run)
    {
        var response = new JobRunResponse
        {
            RunId = run.RunId,
            JobId = run.JobId,
            ScheduledAt = run.ScheduledAt,
            Status = run.Status,
            Attempt = run.Attempt,
            MaxRetry = run.MaxRetry,
            QueueId = run.QueueId,
            WorkerId = run.WorkerId,
            ServerId = run.ServerId,
            StartedAt = run.StartedAt,
            FinishedAt = run.FinishedAt,
            ExecutionDurationMs = run.ExecutionDurationMs,
            OutputJson = run.OutputJson,
            ErrorMessage = run.ErrorMessage,
            Stdout = run.Stdout,
            Stderr = run.Stderr,
            RetryPolicyUsedJson = run.RetryPolicyUsedJson,
            NextRetryAt = run.NextRetryAt,
            CreatedAt = run.CreatedAt,
            UpdatedAt = run.UpdatedAt
        };
        
        // Format execution duration
        if (run.ExecutionDurationMs.HasValue)
        {
            var duration = TimeSpan.FromMilliseconds(run.ExecutionDurationMs.Value);
            if (duration.TotalSeconds < 60)
            {
                response.ExecutionDurationFormatted = $"{duration.TotalSeconds:F2}s";
            }
            else if (duration.TotalMinutes < 60)
            {
                response.ExecutionDurationFormatted = $"{duration.TotalMinutes:F2}m";
            }
            else
            {
                response.ExecutionDurationFormatted = $"{duration.TotalHours:F2}h";
            }
        }
        
        // Status description for logging
        response.StatusDescription = run.Status switch
        {
            JobScheduler.Contracts.Enums.JobRunStatus.Created => "Job run created, waiting to be scheduled",
            JobScheduler.Contracts.Enums.JobRunStatus.Pending => "Scheduled, waiting for execution time",
            JobScheduler.Contracts.Enums.JobRunStatus.Queued => "Queued, waiting for worker",
            JobScheduler.Contracts.Enums.JobRunStatus.Running => $"Running (attempt {run.Attempt}/{run.MaxRetry})",
            JobScheduler.Contracts.Enums.JobRunStatus.Completed => $"Completed successfully in {response.ExecutionDurationFormatted ?? "N/A"}",
            JobScheduler.Contracts.Enums.JobRunStatus.Failed => $"Failed after {run.Attempt} attempt(s)",
            JobScheduler.Contracts.Enums.JobRunStatus.RetryPending => $"Retry pending (attempt {run.Attempt}/{run.MaxRetry})",
            JobScheduler.Contracts.Enums.JobRunStatus.Timeout => "Execution timed out",
            JobScheduler.Contracts.Enums.JobRunStatus.Cancelled => "Cancelled by user",
            _ => run.Status.ToString()
        };
        
        return response;
    }
}
