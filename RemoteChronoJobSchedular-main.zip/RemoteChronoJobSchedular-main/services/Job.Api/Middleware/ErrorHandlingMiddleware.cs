using System.Net;
using System.Text.Json;

namespace Job.Api.Middleware;

/// <summary>
/// Global error handling middleware
/// </summary>
public class ErrorHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ErrorHandlingMiddleware> _logger;

    public ErrorHandlingMiddleware(RequestDelegate next, ILogger<ErrorHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An unhandled exception occurred. RequestId: {RequestId}", 
                context.TraceIdentifier);
            await HandleExceptionAsync(context, ex);
        }
    }

    private static Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        var code = HttpStatusCode.InternalServerError;
        var message = "An error occurred while processing your request.";

        switch (exception)
        {
            case KeyNotFoundException:
                code = HttpStatusCode.NotFound;
                message = exception.Message;
                break;

            case ArgumentException or ArgumentNullException:
                code = HttpStatusCode.BadRequest;
                message = exception.Message;
                break;

            case InvalidOperationException invalidOpEx:
                if (invalidOpEx.Message.Contains("Version mismatch"))
                {
                    code = HttpStatusCode.Conflict;
                    message = invalidOpEx.Message;
                }
                else
                {
                    code = HttpStatusCode.BadRequest;
                    message = invalidOpEx.Message;
                }
                break;

            case UnauthorizedAccessException:
                code = HttpStatusCode.Forbidden;
                message = "You do not have permission to perform this action.";
                break;
        }

        var response = new ErrorResponse
        {
            Error = new ErrorDetail
            {
                Code = code.ToString(),
                Message = message,
                RequestId = context.TraceIdentifier,
                Timestamp = DateTime.UtcNow
            }
        };

        context.Response.ContentType = "application/json";
        context.Response.StatusCode = (int)code;

        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        return context.Response.WriteAsync(JsonSerializer.Serialize(response, options));
    }
}

/// <summary>
/// Error response model
/// </summary>
public class ErrorResponse
{
    public ErrorDetail Error { get; set; } = null!;
}

/// <summary>
/// Error detail model
/// </summary>
public class ErrorDetail
{
    public string Code { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string RequestId { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; }
}
