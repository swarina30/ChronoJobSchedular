using System.ComponentModel.DataAnnotations;
using JobScheduler.Contracts.Enums;

namespace Job.Api.Models.Requests;

/// <summary>
/// Request to create a new job
/// </summary>
public class CreateJobRequest
{
    /// <summary>
    /// Type of job (OneTime or Recurring)
    /// </summary>
    [Required]
    public JobType JobType { get; set; }
    
    /// <summary>
    /// Cron expression for recurring jobs (required if JobType is RECURRING)
    /// </summary>
    public string? CronExpr { get; set; }
    
    /// <summary>
    /// Python script content (stored in DB)
    /// </summary>
    [Required]
    [MinLength(1)]
    public string ScriptContent { get; set; } = string.Empty;
    
    /// <summary>
    /// Arguments to pass to the script (JSON)
    /// </summary>
    public Dictionary<string, object>? Args { get; set; }
    
    /// <summary>
    /// Retry policy configuration
    /// </summary>
    public RetryPolicyRequest? RetryPolicy { get; set; }
    
    /// <summary>
    /// Timeout in seconds (default: 3600)
    /// </summary>
    [Range(1, 86400)]
    public int? TimeoutSeconds { get; set; }
    
    /// <summary>
    /// Scheduled time for one-time jobs (optional, defaults to now)
    /// </summary>
    public DateTime? ScheduledAt { get; set; }
}

/// <summary>
/// Retry policy request
/// </summary>
public class RetryPolicyRequest
{
    /// <summary>
    /// Maximum number of retry attempts
    /// </summary>
    [Range(1, 10)]
    public int MaxAttempts { get; set; } = 3;
    
    /// <summary>
    /// Strategy type: ExponentialBackoff, Linear, or Fixed
    /// </summary>
    public string Strategy { get; set; } = "ExponentialBackoff";
    
    /// <summary>
    /// Initial delay in seconds
    /// </summary>
    [Range(1, 3600)]
    public int InitialDelaySeconds { get; set; } = 5;
    
    /// <summary>
    /// Maximum delay in seconds
    /// </summary>
    [Range(1, 3600)]
    public int MaxDelaySeconds { get; set; } = 300;
    
    /// <summary>
    /// Multiplier for exponential backoff
    /// </summary>
    [Range(1.0, 10.0)]
    public double Multiplier { get; set; } = 2.0;
}
