using System.ComponentModel.DataAnnotations;

namespace Job.Api.Models.Requests;

/// <summary>
/// Request to sign up a new user
/// </summary>
public class SignupRequest
{
    /// <summary>
    /// Username (must be unique)
    /// </summary>
    [Required]
    [MinLength(3)]
    [MaxLength(255)]
    public string Username { get; set; } = string.Empty;
    
    /// <summary>
    /// Email address (must be unique)
    /// </summary>
    [Required]
    [EmailAddress]
    [MaxLength(255)]
    public string Email { get; set; } = string.Empty;
    
    /// <summary>
    /// Password (will be hashed)
    /// </summary>
    [Required]
    [MinLength(6)]
    public string Password { get; set; } = string.Empty;
}
