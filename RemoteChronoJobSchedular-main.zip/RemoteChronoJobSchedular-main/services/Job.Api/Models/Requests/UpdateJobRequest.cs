using System.ComponentModel.DataAnnotations;
using JobScheduler.Contracts.Enums;

namespace Job.Api.Models.Requests;

/// <summary>
/// Request to update an existing job
/// </summary>
public class UpdateJobRequest
{
    /// <summary>
    /// Cron expression for recurring jobs
    /// </summary>
    public string? CronExpr { get; set; }
    
    /// <summary>
    /// Python script content
    /// </summary>
    [MinLength(1)]
    public string? ScriptContent { get; set; }
    
    /// <summary>
    /// Arguments to pass to the script (JSON)
    /// </summary>
    public Dictionary<string, object>? Args { get; set; }
    
    /// <summary>
    /// Retry policy configuration
    /// </summary>
    public RetryPolicyRequest? RetryPolicy { get; set; }
    
    /// <summary>
    /// Timeout in seconds
    /// </summary>
    [Range(1, 86400)]
    public int? TimeoutSeconds { get; set; }
    
    /// <summary>
    /// Expected version for optimistic locking
    /// </summary>
    [Required]
    public int Version { get; set; }
}
