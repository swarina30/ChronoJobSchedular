using JobScheduler.Contracts.Enums;

namespace Job.Api.Models.Responses;

/// <summary>
/// Job definition response
/// </summary>
public class JobResponse
{
    public Guid JobId { get; set; }
    public Guid UserId { get; set; }
    public JobType JobType { get; set; }
    public string? CronExpr { get; set; }
    public JobStatus Status { get; set; }
    public int? TimeoutSeconds { get; set; }
    public RetryPolicyResponse? RetryPolicy { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public int Version { get; set; }
}

/// <summary>
/// Retry policy response
/// </summary>
public class RetryPolicyResponse
{
    public int MaxAttempts { get; set; }
    public string Strategy { get; set; } = string.Empty;
    public int InitialDelaySeconds { get; set; }
    public int MaxDelaySeconds { get; set; }
    public double Multiplier { get; set; }
}

/// <summary>
/// Paged response wrapper
/// </summary>
public class PagedResponse<T>
{
    public List<T> Items { get; set; } = new();
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalPages { get; set; }
}
