using JobScheduler.Contracts.Enums;

namespace Job.Api.Models.Responses;

/// <summary>
/// Job run response model with detailed execution information
/// </summary>
public class JobRunResponse
{
    public Guid RunId { get; set; }
    public Guid JobId { get; set; }
    public DateTime ScheduledAt { get; set; }
    
    public JobRunStatus Status { get; set; }
    public int Attempt { get; set; }
    public int MaxRetry { get; set; }
    public int QueueId { get; set; }
    public string? WorkerId { get; set; }
    public string? ServerId { get; set; }
    
    public DateTime? StartedAt { get; set; }
    public DateTime? FinishedAt { get; set; }
    public long? ExecutionDurationMs { get; set; }
    
    public string? OutputJson { get; set; }
    public string? ErrorMessage { get; set; }
    public string? Stdout { get; set; }
    public string? Stderr { get; set; }
    
    public string? RetryPolicyUsedJson { get; set; }
    public DateTime? NextRetryAt { get; set; }
    
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    
    /// <summary>
    /// Human-readable execution duration
    /// </summary>
    public string? ExecutionDurationFormatted { get; set; }
    
    /// <summary>
    /// Status description for logging
    /// </summary>
    public string StatusDescription { get; set; } = string.Empty;
}
