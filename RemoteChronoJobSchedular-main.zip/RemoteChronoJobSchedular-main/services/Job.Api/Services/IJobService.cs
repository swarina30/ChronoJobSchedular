using Job.Api.Models.Requests;
using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Interfaces;

namespace Job.Api.Services;

/// <summary>
/// Job service interface (business logic layer)
/// </summary>
public interface IJobService
{
    /// <summary>
    /// Create a new job
    /// </summary>
    Task<JobDefinition> CreateJobAsync(Guid userId, CreateJobRequest request, CancellationToken ct = default);
    
    /// <summary>
    /// Get job by ID (with ownership check)
    /// </summary>
    Task<JobDefinition?> GetJobByIdAsync(Guid jobId, Guid userId, CancellationToken ct = default);
    
    /// <summary>
    /// Update job (with ownership check and optimistic locking)
    /// </summary>
    Task<JobDefinition> UpdateJobAsync(Guid jobId, Guid userId, UpdateJobRequest request, CancellationToken ct = default);
    
    /// <summary>
    /// Delete job (soft delete with ownership check)
    /// </summary>
    Task<bool> DeleteJobAsync(Guid jobId, Guid userId, CancellationToken ct = default);
    
    /// <summary>
    /// Get paged jobs by user ID
    /// </summary>
    Task<PagedResult<JobDefinition>> GetJobsByUserIdAsync(Guid userId, int page, int pageSize, CancellationToken ct = default);
    
    /// <summary>
    /// Pause recurring job
    /// </summary>
    Task<JobDefinition?> PauseJobAsync(Guid jobId, Guid userId, CancellationToken ct = default);
    
    /// <summary>
    /// Resume recurring job
    /// </summary>
    Task<JobDefinition?> ResumeJobAsync(Guid jobId, Guid userId, CancellationToken ct = default);
}
