using Job.Api.Builders;
using Job.Api.Models.Requests;
using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Contracts.Models;
using JobScheduler.Infrastructure.Scheduling;
using System.Text.Json;

namespace Job.Api.Services;

/// <summary>
/// Job service implementation (business logic layer)
/// </summary>
public class JobService : IJobService
{
    private readonly IJobDefinitionRepository _repository;
    private readonly IJobScheduleStateRepository _scheduleStateRepository;
    private readonly IJobRunRepository _runRepository;
    private readonly ILogger<JobService> _logger;
    private readonly string? _serverId; // For multi-instance tracking

    public JobService(
        IJobDefinitionRepository repository,
        IJobScheduleStateRepository scheduleStateRepository,
        IJobRunRepository runRepository,
        ILogger<JobService> logger,
        IConfiguration configuration)
    {
        _repository = repository;
        _scheduleStateRepository = scheduleStateRepository;
        _runRepository = runRepository;
        _logger = logger;
        _serverId = configuration["ServerId"] ?? Environment.MachineName;
    }

    public async Task<JobDefinition> CreateJobAsync(Guid userId, CreateJobRequest request, CancellationToken ct = default)
    {
        _logger.LogInformation("Creating job for user {UserId}, type: {JobType}", userId, request.JobType);

        // Validate request
        ValidateCreateRequest(request);

        // Build retry policy
        var retryPolicy = BuildRetryPolicy(request.RetryPolicy);

        // Build job entity using Builder pattern
        var jobBuilder = JobDefinitionBuilder
            .Create(userId, userId) // createdBy = userId
            .WithType(request.JobType)
            .WithScriptContent(request.ScriptContent)
            .WithArguments(request.Args)
            .WithRetryPolicy(retryPolicy)
            .WithServerId(_serverId)
            .WithStatus(JobStatus.Active); // Jobs are Active by default (can be paused later)

        if (request.JobType == JobType.Recurring)
        {
            if (string.IsNullOrWhiteSpace(request.CronExpr))
            {
                throw new ArgumentException("Cron expression is required for recurring jobs", nameof(request));
            }
            jobBuilder.WithCron(request.CronExpr);
        }

        if (request.TimeoutSeconds.HasValue)
        {
            jobBuilder.WithTimeout(request.TimeoutSeconds.Value);
        }

        var job = jobBuilder.Build();

        // Save to repository
        var createdJob = await _repository.CreateAsync(job, ct);

        // Handle one-time vs recurring jobs differently
        if (createdJob.JobType == JobType.OneTime)
        {
            // ONE-TIME JOB: Create single JobRun immediately (no job_schedule_state)
            try
            {
                var scheduledAt = request.ScheduledAt ?? DateTime.UtcNow;
                var maxRetry = retryPolicy?.MaxAttempts ?? 3;

                var jobRun = new JobRun
                {
                    RunId = Guid.NewGuid(),
                    JobId = createdJob.JobId,
                    ScheduledAt = scheduledAt,
                    Status = JobRunStatus.Pending,
                    Attempt = 0,
                    MaxRetry = maxRetry,
                    QueueId = 0, // Will be calculated during dispatch
                    ServerId = _serverId,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                await _runRepository.CreateAsync(jobRun, ct);

                _logger.LogInformation("Created one-time job {JobId} with run {RunId} scheduled at {ScheduledAt}", 
                    createdJob.JobId, jobRun.RunId, scheduledAt);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create job run for one-time job {JobId}, but job was created", createdJob.JobId);
                // Don't fail job creation if run creation fails - can be retried
            }
        }
        else if (createdJob.JobType == JobType.Recurring && createdJob.Status == JobStatus.Active)
        {
            // RECURRING JOB: Create JobScheduleState (scheduler will create runs)
            try
            {
                // Calculate first possible run time
                var firstRunTime = CronExpressionParser.GetNextScheduledTime(
                    createdJob.CronExpr!,
                    DateTime.UtcNow);

                // Create schedule state
                var scheduleState = await _scheduleStateRepository.GetOrCreateAsync(createdJob.JobId, ct);
                
                // Set initial last_scheduled_at to current time (scheduler will advance from here)
                await _scheduleStateRepository.UpdateLastScheduledAtAsync(
                    createdJob.JobId,
                    DateTime.UtcNow, // Start from now
                    firstRunTime,    // Next run time
                    ct);

                _logger.LogInformation("Created schedule state for recurring job {JobId}, first run at {FirstRunTime}", 
                    createdJob.JobId, firstRunTime);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create schedule state for job {JobId}, but job was created", createdJob.JobId);
                // Don't fail job creation if schedule state creation fails - scheduler can create it lazily
            }
        }

        _logger.LogInformation("Job created successfully: {JobId}", createdJob.JobId);

        return createdJob;
    }

    public async Task<JobDefinition?> GetJobByIdAsync(Guid jobId, Guid userId, CancellationToken ct = default)
    {
        var job = await _repository.GetByIdAsync(jobId, ct);
        
        if (job == null)
        {
            _logger.LogWarning("Job not found: {JobId}", jobId);
            return null;
        }

        // Check ownership
        if (job.UserId != userId)
        {
            throw new UnauthorizedAccessException($"User {userId} does not have access to job {jobId}");
        }

        return job;
    }

    public async Task<JobDefinition> UpdateJobAsync(Guid jobId, Guid userId, UpdateJobRequest request, CancellationToken ct = default)
    {
        _logger.LogInformation("Updating job {JobId} for user {UserId}", jobId, userId);

        var existingJob = await _repository.GetByIdAsync(jobId, ct);
        if (existingJob == null)
        {
            throw new KeyNotFoundException($"Job with ID {jobId} not found");
        }

        // Check ownership
        if (existingJob.UserId != userId)
        {
            throw new UnauthorizedAccessException($"User {userId} does not have access to job {jobId}");
        }

        // Optimistic locking check
        if (existingJob.Version != request.Version)
        {
            throw new InvalidOperationException($"Version mismatch. Expected {request.Version}, got {existingJob.Version}");
        }

        // Update fields (only non-null values)
        if (!string.IsNullOrWhiteSpace(request.ScriptContent))
        {
            existingJob.ScriptContent = request.ScriptContent;
        }

        var cronChanged = false;
        var oldCron = existingJob.CronExpr;
        if (request.CronExpr != null && oldCron != request.CronExpr)
        {
            cronChanged = true;
            existingJob.CronExpr = request.CronExpr;
            
            _logger.LogInformation("Cron expression changed for job {JobId}: {OldCron} -> {NewCron}", 
                jobId, oldCron ?? "null", request.CronExpr);
        }

        if (request.Args != null)
        {
            existingJob.ArgsJson = JsonSerializer.Serialize(request.Args);
        }

        if (request.RetryPolicy != null)
        {
            var retryPolicy = BuildRetryPolicy(request.RetryPolicy);
            existingJob.RetryPolicyJson = JsonSerializer.Serialize(retryPolicy);
        }

        if (request.TimeoutSeconds.HasValue)
        {
            existingJob.TimeoutSeconds = request.TimeoutSeconds;
        }

        existingJob.UpdatedBy = userId;
        existingJob.UpdatedAt = DateTime.UtcNow;
        existingJob.Version++; // Increment for optimistic locking

        // Update via repository (with version check)
        var updatedJob = await _repository.UpdateAsync(existingJob, request.Version, ct);

        // If cron changed, cleanup pending runs and reset schedule state (standard practice)
        if (cronChanged && updatedJob.JobType == JobType.Recurring)
        {
            try
            {
                // 1. Cancel all PENDING and QUEUED runs (let RUNNING complete)
                var cancelledCount = await _runRepository.CancelPendingRunsForJobAsync(updatedJob.JobId, ct);
                _logger.LogInformation("Cancelled {Count} pending/queued runs for job {JobId} due to cron change", 
                    cancelledCount, updatedJob.JobId);

                // 2. Reset schedule state to recalculate from now with new cron
                if (!string.IsNullOrWhiteSpace(updatedJob.CronExpr))
                {
                    var scheduleState = await _scheduleStateRepository.GetOrCreateAsync(updatedJob.JobId, ct);
                    
                    // Reset LastScheduledAt to now, so next runs use new cron from current time
                    var nextRunTime = CronExpressionParser.GetNextScheduledTime(
                        updatedJob.CronExpr,
                        DateTime.UtcNow);
                    
                    await _scheduleStateRepository.UpdateLastScheduledAtAsync(
                        updatedJob.JobId,
                        DateTime.UtcNow,
                        nextRunTime,
                        ct);
                    
                    _logger.LogInformation("Reset schedule state for job {JobId}. Next run: {NextRunTime}", 
                        updatedJob.JobId, nextRunTime);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error cleaning up runs after cron change for job {JobId}", updatedJob.JobId);
                // Continue - job update succeeded, scheduler will handle cleanup
            }
        }

        _logger.LogInformation("Job updated successfully: {JobId}, new version: {Version}", updatedJob.JobId, updatedJob.Version);

        return updatedJob;
    }

    public async Task<bool> DeleteJobAsync(Guid jobId, Guid userId, CancellationToken ct = default)
    {
        _logger.LogInformation("Deleting job {JobId} for user {UserId}", jobId, userId);

        var job = await _repository.GetByIdAsync(jobId, ct);
        if (job == null)
        {
            return false;
        }

        // Check ownership
        if (job.UserId != userId)
        {
            throw new UnauthorizedAccessException($"User {userId} does not have access to job {jobId}");
        }

        var deleted = await _repository.DeleteAsync(jobId, userId, ct);

        if (deleted)
        {
            // Cancel all PENDING and QUEUED runs (standard practice: let RUNNING complete)
            try
            {
                var cancelledCount = await _runRepository.CancelPendingRunsForJobAsync(jobId, ct);
                _logger.LogInformation("Cancelled {Count} pending/queued runs for deleted job {JobId}", 
                    cancelledCount, jobId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to cancel pending runs for deleted job {JobId}", jobId);
            }

            _logger.LogInformation("Job deleted successfully: {JobId}", jobId);
        }

        return deleted;
    }

    public async Task<PagedResult<JobDefinition>> GetJobsByUserIdAsync(Guid userId, int page, int pageSize, CancellationToken ct = default)
    {
        return await _repository.GetByUserIdAsync(userId, page, pageSize, includeDeleted: false, ct);
    }

    public async Task<JobDefinition?> PauseJobAsync(Guid jobId, Guid userId, CancellationToken ct = default)
    {
        _logger.LogInformation("Pausing job {JobId} for user {UserId}", jobId, userId);

        var job = await _repository.GetByIdAsync(jobId, ct);
        if (job == null || job.JobType != JobType.Recurring)
        {
            return null;
        }

        // Check ownership
        if (job.UserId != userId)
        {
            throw new UnauthorizedAccessException($"User {userId} does not have access to job {jobId}");
        }

        if (job.Status != JobStatus.Active)
        {
            _logger.LogWarning("Cannot pause job {JobId} - status is {Status}", jobId, job.Status);
            return job; // Return as-is
        }

        job.Status = JobStatus.Paused;
        job.UpdatedBy = userId;
        job.UpdatedAt = DateTime.UtcNow;
        job.Version++;

        var updatedJob = await _repository.UpdateAsync(job, job.Version - 1, ct);

        // Deactivate schedule state (standard practice)
        try
        {
            var scheduleState = await _scheduleStateRepository.GetOrCreateAsync(jobId, ct);
            if (scheduleState.IsActive)
            {
                await _scheduleStateRepository.DeactivateAsync(jobId, ct);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to deactivate schedule state for job {JobId}", jobId);
        }

        // Cancel all PENDING and QUEUED runs (standard practice: let RUNNING complete)
        try
        {
            var cancelledCount = await _runRepository.CancelPendingRunsForJobAsync(jobId, ct);
            _logger.LogInformation("Cancelled {Count} pending/queued runs for paused job {JobId}", 
                cancelledCount, jobId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to cancel pending runs for job {JobId}", jobId);
        }

        _logger.LogInformation("Job paused successfully: {JobId}", jobId);

        return updatedJob;
    }

    public async Task<JobDefinition?> ResumeJobAsync(Guid jobId, Guid userId, CancellationToken ct = default)
    {
        _logger.LogInformation("Resuming job {JobId} for user {UserId}", jobId, userId);

        var job = await _repository.GetByIdAsync(jobId, ct);
        if (job == null || job.JobType != JobType.Recurring)
        {
            return null;
        }

        // Check ownership
        if (job.UserId != userId)
        {
            throw new UnauthorizedAccessException($"User {userId} does not have access to job {jobId}");
        }

        if (job.Status != JobStatus.Paused)
        {
            _logger.LogWarning("Cannot resume job {JobId} - status is {Status}", jobId, job.Status);
            return job; // Return as-is
        }

        job.Status = JobStatus.Active;
        job.UpdatedBy = userId;
        job.UpdatedAt = DateTime.UtcNow;
        job.Version++;

        var updatedJob = await _repository.UpdateAsync(job, job.Version - 1, ct);

        // Ensure schedule state exists when resuming
        if (!string.IsNullOrWhiteSpace(updatedJob.CronExpr))
        {
            try
            {
                var scheduleState = await _scheduleStateRepository.GetOrCreateAsync(updatedJob.JobId, ct);
                
                // Activate if it was deactivated
                if (!scheduleState.IsActive)
                {
                    await _scheduleStateRepository.ActivateAsync(updatedJob.JobId, ct);
                }

                // Update next run time if needed
                var nextRunTime = CronExpressionParser.GetNextScheduledTime(
                    updatedJob.CronExpr,
                    DateTime.UtcNow);
                
                await _scheduleStateRepository.UpdateLastScheduledAtAsync(
                    updatedJob.JobId,
                    DateTime.UtcNow,
                    nextRunTime,
                    ct);

                _logger.LogInformation("Activated schedule state for resumed job {JobId}", updatedJob.JobId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to activate schedule state for job {JobId}", updatedJob.JobId);
                // Continue - scheduler can handle this
            }
        }

        _logger.LogInformation("Job resumed successfully: {JobId}", jobId);

        return updatedJob;
    }

    // Helper methods

    private static void ValidateCreateRequest(CreateJobRequest request)
    {
        if (request.JobType == JobType.Recurring && string.IsNullOrWhiteSpace(request.CronExpr))
        {
            throw new ArgumentException("Cron expression is required for recurring jobs", nameof(request));
        }

        if (string.IsNullOrWhiteSpace(request.ScriptContent))
        {
            throw new ArgumentException("Script content is required", nameof(request));
        }
    }

    private static RetryPolicy BuildRetryPolicy(RetryPolicyRequest? request)
    {
        if (request == null)
        {
            // Default retry policy
            return new RetryPolicy
            {
                MaxAttempts = 3,
                Strategy = "ExponentialBackoff",
                InitialDelaySeconds = 5,
                MaxDelaySeconds = 300,
                Multiplier = 2.0
            };
        }

        return new RetryPolicy
        {
            MaxAttempts = request.MaxAttempts,
            Strategy = request.Strategy,
            InitialDelaySeconds = request.InitialDelaySeconds,
            MaxDelaySeconds = request.MaxDelaySeconds,
            Multiplier = request.Multiplier
        };
    }
}
