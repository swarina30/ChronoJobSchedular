using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Data.Data;
using JobScheduler.Infrastructure.Redis;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StackExchange.Redis;

namespace Job.Monitor.Controllers;

/// <summary>
/// Health and monitoring controller
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class HealthController : ControllerBase
{
    private readonly JobSchedulerDbContext _context;
    private readonly RedisConnectionService _redisConnection;
    private readonly IJobRunRepository _runRepository;
    private readonly IJobDefinitionRepository _jobRepository;
    private readonly IQueueService _queueService;
    private readonly ILogger<HealthController> _logger;

    public HealthController(
        JobSchedulerDbContext context,
        RedisConnectionService redisConnection,
        IJobRunRepository runRepository,
        IJobDefinitionRepository jobRepository,
        IQueueService queueService,
        ILogger<HealthController> logger)
    {
        _context = context;
        _redisConnection = redisConnection;
        _runRepository = runRepository;
        _jobRepository = jobRepository;
        _queueService = queueService;
        _logger = logger;
    }

    /// <summary>
    /// Get system health status
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<HealthResponse>> GetHealth(CancellationToken ct = default)
    {
        _logger.LogInformation("Health check requested");

        var health = new HealthResponse
        {
            Timestamp = DateTime.UtcNow,
            Status = "Healthy"
        };

        // Check database
        try
        {
            var canConnect = await _context.Database.CanConnectAsync(ct);
            health.Database = new ComponentHealth
            {
                Status = canConnect ? "Healthy" : "Unhealthy",
                Message = canConnect ? "Connected" : "Cannot connect to database"
            };

            if (canConnect)
            {
                // Get job statistics
                var totalJobs = await _context.JobDefinitions.CountAsync(j => j.DeletedAt == null, ct);
                var activeJobs = await _context.JobDefinitions.CountAsync(j => j.DeletedAt == null && j.Status == JobStatus.Active, ct);
                var totalRuns = await _context.JobRuns.CountAsync(ct);
                
                health.Database.Metrics = new Dictionary<string, object>
                {
                    { "totalJobs", totalJobs },
                    { "activeJobs", activeJobs },
                    { "totalRuns", totalRuns }
                };
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Database health check failed");
            health.Database = new ComponentHealth
            {
                Status = "Unhealthy",
                Message = ex.Message
            };
            health.Status = "Degraded";
        }

        // Check Redis
        try
        {
            var redis = _redisConnection.Database;
            await redis.PingAsync();
            
            // Get queue statistics
            var queueLengths = new Dictionary<string, long>();
            var totalQueueLength = 0L;
            for (int i = 0; i < 16; i++)
            {
                var length = await _queueService.GetLengthAsync(i, ct);
                queueLengths[$"queue:{i}"] = length;
                totalQueueLength += length;
            }

            // Check Redis ZSET (heartbeats)
            var heartbeatCount = await redis.SortedSetLengthAsync("running_jobs");

            health.Redis = new ComponentHealth
            {
                Status = "Healthy",
                Message = "Connected",
                Metrics = new Dictionary<string, object>
                {
                    { "totalQueuedJobs", totalQueueLength },
                    { "activeHeartbeats", heartbeatCount },
                    { "queueLengths", queueLengths }
                }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Redis health check failed");
            health.Redis = new ComponentHealth
            {
                Status = "Unhealthy",
                Message = ex.Message
            };
            health.Status = "Unhealthy";
        }

        // Get job run statistics
        try
        {
            var runningJobs = await _runRepository.GetRunningJobsAsync(ct);
            var pendingRuns = await _runRepository.GetPendingRunsAsync(100, ct);

            health.JobRuns = new Dictionary<string, object>
            {
                { "running", runningJobs.Count },
                { "pending", pendingRuns.Count }
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to get job run statistics");
        }

        var statusCode = health.Status switch
        {
            "Healthy" => 200,
            "Degraded" => 200, // Still operational
            _ => 503 // Service Unavailable
        };

        return StatusCode(statusCode, health);
    }

    /// <summary>
    /// Get detailed system metrics
    /// </summary>
    [HttpGet("metrics")]
    public async Task<ActionResult<MetricsResponse>> GetMetrics(CancellationToken ct = default)
    {
        _logger.LogInformation("Metrics requested");

        var metrics = new MetricsResponse
        {
            Timestamp = DateTime.UtcNow
        };

        try
        {
            // Job statistics
            var totalJobs = await _context.JobDefinitions.CountAsync(j => j.DeletedAt == null, ct);
            var activeJobs = await _context.JobDefinitions.CountAsync(j => j.DeletedAt == null && j.Status == JobStatus.Active, ct);
            var pausedJobs = await _context.JobDefinitions.CountAsync(j => j.DeletedAt == null && j.Status == JobStatus.Paused, ct);
            
            metrics.Jobs = new JobMetrics
            {
                Total = totalJobs,
                Active = activeJobs,
                Paused = pausedJobs
            };

            // Job run statistics by status
            var runsByStatus = await _context.JobRuns
                .GroupBy(r => r.Status)
                .Select(g => new { Status = g.Key, Count = g.Count() })
                .ToListAsync(ct);

            metrics.JobRuns = new JobRunMetrics
            {
                Total = await _context.JobRuns.CountAsync(ct),
                ByStatus = runsByStatus.ToDictionary(r => r.Status.ToString(), r => r.Count)
            };

            // Queue statistics
            var queueStats = new Dictionary<string, long>();
            var totalQueued = 0L;
            for (int i = 0; i < 16; i++)
            {
                var length = await _queueService.GetLengthAsync(i, ct);
                queueStats[$"queue:{i}"] = length;
                totalQueued += length;
            }
            metrics.Queues = new QueueMetrics
            {
                TotalQueued = totalQueued,
                QueueLengths = queueStats
            };

            // Redis heartbeat statistics
            var redis = _redisConnection.Database;
            var heartbeatCount = await redis.SortedSetLengthAsync("running_jobs");
            metrics.Redis = new RedisMetrics
            {
                ActiveHeartbeats = heartbeatCount
            };

            _logger.LogInformation("Metrics retrieved successfully. Total jobs: {TotalJobs}, Total runs: {TotalRuns}, Queued: {Queued}", 
                metrics.Jobs.Total, metrics.JobRuns.Total, metrics.Queues.TotalQueued);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve metrics");
            return StatusCode(500, new { error = "Failed to retrieve metrics", message = ex.Message });
        }

        return Ok(metrics);
    }
}

/// <summary>
/// Health response model
/// </summary>
public class HealthResponse
{
    public DateTime Timestamp { get; set; }
    public string Status { get; set; } = string.Empty;
    public ComponentHealth Database { get; set; } = new();
    public ComponentHealth Redis { get; set; } = new();
    public Dictionary<string, object>? JobRuns { get; set; }
}

/// <summary>
/// Component health status
/// </summary>
public class ComponentHealth
{
    public string Status { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public Dictionary<string, object>? Metrics { get; set; }
}

/// <summary>
/// Metrics response model
/// </summary>
public class MetricsResponse
{
    public DateTime Timestamp { get; set; }
    public JobMetrics Jobs { get; set; } = new();
    public JobRunMetrics JobRuns { get; set; } = new();
    public QueueMetrics Queues { get; set; } = new();
    public RedisMetrics Redis { get; set; } = new();
}

public class JobMetrics
{
    public int Total { get; set; }
    public int Active { get; set; }
    public int Paused { get; set; }
}

public class JobRunMetrics
{
    public int Total { get; set; }
    public Dictionary<string, int> ByStatus { get; set; } = new();
}

public class QueueMetrics
{
    public long TotalQueued { get; set; }
    public Dictionary<string, long> QueueLengths { get; set; } = new();
}

public class RedisMetrics
{
    public long ActiveHeartbeats { get; set; }
}
