using Job.Monitor.Controllers;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Data.Data;
using JobScheduler.Data.Repositories;
using JobScheduler.Infrastructure.Queue;
using JobScheduler.Infrastructure.Redis;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using Serilog;

// Configure Serilog
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/monitor-.log", rollingInterval: RollingInterval.Day)
    .CreateLogger();

var builder = WebApplication.CreateBuilder(args);

// Use Serilog for logging
builder.Host.UseSerilog();

// Add services
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.Converters.Add(new System.Text.Json.Serialization.JsonStringEnumConverter());
    });
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Database configuration
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

builder.Services.AddDbContext<JobSchedulerDbContext>(options =>
{
    var serverVersion = ServerVersion.Create(new Version(8, 0, 0), ServerType.MySql);
    options.UseMySql(connectionString, serverVersion);
});

// Repositories
builder.Services.AddScoped<IJobRunRepository, JobRunRepository>();
builder.Services.AddScoped<IJobDefinitionRepository, JobDefinitionRepository>();

// Redis
builder.Services.AddSingleton<RedisConnectionService>();
builder.Services.AddScoped<IQueueService, RedisQueueService>();

// CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors();
app.UseAuthorization();
app.MapControllers();

Log.Information("Job Monitor Service starting...");

app.Run();
