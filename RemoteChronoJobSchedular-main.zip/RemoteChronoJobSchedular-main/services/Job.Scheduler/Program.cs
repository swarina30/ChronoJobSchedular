using Job.Scheduler.Services;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Data.Data;
using JobScheduler.Data.Repositories;
using JobScheduler.Infrastructure.Queue;
using JobScheduler.Infrastructure.Redis;
using JobScheduler.Infrastructure.Services;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;

var builder = Host.CreateApplicationBuilder(args);

// Database configuration
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

builder.Services.AddDbContext<JobSchedulerDbContext>(options =>
{
    var serverVersion = ServerVersion.Create(new Version(8, 0, 0), ServerType.MySql);
    options.UseMySql(connectionString, serverVersion);
});

// Repositories
builder.Services.AddScoped<IJobDefinitionRepository, JobDefinitionRepository>();
builder.Services.AddScoped<IJobScheduleStateRepository, JobScheduleStateRepository>();
builder.Services.AddScoped<IJobRunRepository, JobRunRepository>();

// Redis
builder.Services.AddSingleton<RedisConnectionService>();
builder.Services.AddScoped<IQueueService, RedisQueueService>();
// IRedisHeartbeatService can be singleton (Redis connection is singleton)
builder.Services.AddSingleton<IRedisHeartbeatService, RedisHeartbeatService>();

// Infrastructure services
builder.Services.AddSingleton<RetryPolicyService>();

// ============================================
// SCHEDULER BUSINESS LOGIC (Core Loops)
// ============================================
builder.Services.AddHostedService<FutureRunCreator>();
builder.Services.AddHostedService<RunDispatcher>();
builder.Services.AddHostedService<HeartbeatMonitor>();

// ============================================
// INFRASTRUCTURE CODE - Partition Management
// Note: This is platform/infrastructure concern, not business logic.
// In production, this would typically be a separate service or DB job.
// ============================================
builder.Services.AddHostedService<PartitionMaintenanceService>();

// Logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

var host = builder.Build();
host.Run();
