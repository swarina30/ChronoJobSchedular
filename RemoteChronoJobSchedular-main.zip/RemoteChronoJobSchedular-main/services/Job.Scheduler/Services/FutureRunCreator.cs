using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Infrastructure.Scheduling;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace Job.Scheduler.Services;

/// <summary>
/// Loop A: Creates future runs for active recurring jobs
/// Runs every ~60 seconds
/// </summary>
public class FutureRunCreator : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<FutureRunCreator> _logger;
    private readonly string? _schedulerId;
    private const int FutureRunsToMaintain = 5;
    private const int LoopIntervalSeconds = 60;

    public FutureRunCreator(
        IServiceScopeFactory scopeFactory,
        ILogger<FutureRunCreator> logger,
        IConfiguration configuration)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
        _schedulerId = configuration["SchedulerId"] ?? Environment.MachineName;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("FutureRunCreator started. SchedulerId: {SchedulerId}", _schedulerId);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                await CreateFutureRunsAsync(scope, stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in FutureRunCreator loop");
            }

            await Task.Delay(TimeSpan.FromSeconds(LoopIntervalSeconds), stoppingToken);
        }
    }

    private async Task CreateFutureRunsAsync(IServiceScope scope, CancellationToken ct)
    {
        var scheduleRepository = scope.ServiceProvider.GetRequiredService<IJobScheduleStateRepository>();
        var jobRepository = scope.ServiceProvider.GetRequiredService<IJobDefinitionRepository>();
        var runRepository = scope.ServiceProvider.GetRequiredService<IJobRunRepository>();

        // Get active recurring jobs from schedule state
        var activeJobs = await scheduleRepository.GetActiveRecurringJobsAsync(ct);
        
        _logger.LogInformation("FutureRunCreator: Processing {Count} active recurring jobs with schedule state", activeJobs.Count);

        // Also get active recurring jobs that might not have schedule state yet (lazy creation)
        var activeRecurringJobsWithoutState = await jobRepository.GetActiveRecurringJobsAsync(ct);
        var jobsWithState = activeJobs.Select(s => s.JobId).ToHashSet();
        var jobsNeedingState = activeRecurringJobsWithoutState
            .Where(j => !jobsWithState.Contains(j.JobId) && j.Status == JobStatus.Active)
            .ToList();

        // Create schedule state for jobs that don't have it yet (lazy creation)
        foreach (var job in jobsNeedingState)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(job.CronExpr))
                {
                    _logger.LogWarning("Job {JobId} is recurring but has no cron expression", job.JobId);
                    continue;
                }

                // Create schedule state lazily
                var scheduleState = await scheduleRepository.GetOrCreateAsync(job.JobId, ct);
                
                // Set Job navigation property (needed for processing)
                scheduleState.Job = job;
                
                // Set initial last_scheduled_at
                var firstRunTime = CronExpressionParser.GetNextScheduledTime(job.CronExpr, DateTime.UtcNow);
                await scheduleRepository.UpdateLastScheduledAtAsync(
                    job.JobId,
                    DateTime.UtcNow,
                    firstRunTime,
                    ct);

                _logger.LogInformation("Created schedule state lazily for job {JobId}", job.JobId);
                
                // Add to activeJobs list for processing
                activeJobs.Add(scheduleState);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create schedule state for job {JobId}", job.JobId);
            }
        }

        if (activeJobs.Count == 0)
        {
            return; // No jobs to process
        }

        // BATCH OPERATION: Get pending run counts for all jobs in one query
        var pendingRunCounts = await runRepository.GetPendingRunCountsByJobIdAsync(ct);
        
        // Collect all runs to create and state updates
        var runsToCreate = new List<JobRun>();
        var stateUpdates = new List<(Guid JobId, DateTime LastScheduledAt, DateTime? NextRunAt)>();

        foreach (var scheduleState in activeJobs)
        {
            try
            {
                var job = scheduleState.Job;
                
                if (string.IsNullOrWhiteSpace(job.CronExpr))
                {
                    _logger.LogWarning("Job {JobId} has no cron expression", job.JobId);
                    continue;
                }

                // Get pending run count from batch query (default to 0 if not found)
                var existingRuns = pendingRunCounts.GetValueOrDefault(job.JobId, 0);
                
                _logger.LogInformation("FutureRunCreator: Job {JobId} has {ExistingRuns} pending runs (need {RequiredRuns})", 
                    job.JobId, existingRuns, FutureRunsToMaintain);
                
                if (existingRuns >= FutureRunsToMaintain)
                {
                    _logger.LogDebug("FutureRunCreator: Job {JobId} already has enough runs, skipping", job.JobId);
                    continue; // Already have enough future runs
                }

                // Create missing future runs (in memory, batch insert later)
                var runsNeeded = FutureRunsToMaintain - existingRuns;
                var lastScheduled = scheduleState.LastScheduledAt;
                var maxRetry = ParseMaxRetry(job.RetryPolicyJson);
                
                _logger.LogInformation("FutureRunCreator: Creating {RunsNeeded} runs for job {JobId}, lastScheduled: {LastScheduled}", 
                    runsNeeded, job.JobId, lastScheduled);
                
                for (int i = 0; i < runsNeeded; i++)
                {
                    DateTime nextTime;
                    try
                    {
                        nextTime = CronExpressionParser.GetNextScheduledTime(job.CronExpr, lastScheduled);
                        _logger.LogDebug("FutureRunCreator: Job {JobId}, run {RunIndex}: nextTime = {NextTime}", 
                            job.JobId, i + 1, nextTime);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "FutureRunCreator: Failed to parse cron '{CronExpr}' for job {JobId}. Skipping this job.", 
                            job.CronExpr, job.JobId);
                        break; // Skip this job, continue with others
                    }
                    
                    var run = new JobRun
                    {
                        RunId = Guid.NewGuid(),
                        JobId = job.JobId,
                        ScheduledAt = nextTime,
                        Status = JobRunStatus.Pending,
                        Attempt = 0,
                        MaxRetry = maxRetry,
                        QueueId = 0, // Will be calculated during dispatch
                        ServerId = _schedulerId,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    };

                    runsToCreate.Add(run);
                    lastScheduled = nextTime;
                }

                // Collect state update (batch update later)
                var nextRunAt = CronExpressionParser.GetNextScheduledTime(job.CronExpr, lastScheduled);
                stateUpdates.Add((job.JobId, lastScheduled, nextRunAt));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error preparing future runs for job {JobId}", scheduleState.JobId);
            }
        }

        // BATCH OPERATION: Create all runs in a single transaction
        if (runsToCreate.Count > 0)
        {
            await runRepository.BatchCreateAsync(runsToCreate, ct);
            _logger.LogInformation("Batch created {Count} future runs for {JobCount} jobs", 
                runsToCreate.Count, stateUpdates.Count);
        }

        // BATCH OPERATION: Update all schedule states in a single transaction
        if (stateUpdates.Count > 0)
        {
            await scheduleRepository.BatchUpdateLastScheduledAtAsync(stateUpdates, ct);
            _logger.LogDebug("Batch updated {Count} schedule states", stateUpdates.Count);
        }
    }

    private static int ParseMaxRetry(string? retryPolicyJson)
    {
        if (string.IsNullOrWhiteSpace(retryPolicyJson))
        {
            return 3; // Default
        }

        try
        {
            var policy = System.Text.Json.JsonSerializer.Deserialize<JobScheduler.Contracts.Models.RetryPolicy>(retryPolicyJson);
            return policy?.MaxAttempts ?? 3;
        }
        catch
        {
            return 3;
        }
    }
}
