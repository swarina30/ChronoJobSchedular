using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Contracts.Models;
using JobScheduler.Infrastructure.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Job.Scheduler.Services;

/// <summary>
/// Loop C: Monitors heartbeats and marks dead jobs as RETRY_PENDING or FAILED
/// Runs every ~10 seconds
/// </summary>
public class HeartbeatMonitor : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly RetryPolicyService _retryPolicyService;
    private readonly ILogger<HeartbeatMonitor> _logger;
    private const int LoopIntervalSeconds = 10;
    private const int StaleThresholdSeconds = 60;

    public HeartbeatMonitor(
        IServiceScopeFactory scopeFactory,
        RetryPolicyService retryPolicyService,
        ILogger<HeartbeatMonitor> logger)
    {
        _scopeFactory = scopeFactory;
        _retryPolicyService = retryPolicyService;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("HeartbeatMonitor started");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                await MonitorHeartbeatsAsync(scope, stoppingToken);
                
                var heartbeatService = scope.ServiceProvider.GetRequiredService<IRedisHeartbeatService>();
                // Cleanup stale entries periodically
                await heartbeatService.CleanupStaleEntriesAsync(StaleThresholdSeconds, stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in HeartbeatMonitor loop");
            }

            await Task.Delay(TimeSpan.FromSeconds(LoopIntervalSeconds), stoppingToken);
        }
    }

    private async Task MonitorHeartbeatsAsync(IServiceScope scope, CancellationToken ct)
    {
        var runRepository = scope.ServiceProvider.GetRequiredService<IJobRunRepository>();
        var heartbeatService = scope.ServiceProvider.GetRequiredService<IRedisHeartbeatService>();

        // Get all running jobs from DB
        var runningJobs = await runRepository.GetRunningJobsAsync(ct);
        
        if (runningJobs.Count == 0)
        {
            return; // No running jobs
        }

        // Get active run IDs from Redis ZSET
        var activeRunIds = await heartbeatService.GetActiveRunIdsAsync(ct);
        
        _logger.LogDebug("Monitoring {Count} running jobs, {ActiveCount} active in Redis", 
            runningJobs.Count, activeRunIds.Count);

        foreach (var job in runningJobs)
        {
            if (activeRunIds.Contains(job.RunId))
            {
                continue; // Job is alive, heartbeat exists
            }

            // Heartbeat missing - worker likely crashed
            _logger.LogWarning("Missing heartbeat for run {RunId}, attempt {Attempt}/{MaxRetry}", 
                job.RunId, job.Attempt, job.MaxRetry);

            // Get full job run to check retry policy
            var fullJob = await runRepository.GetByIdAsync(job.RunId, ct);
            if (fullJob == null)
            {
                continue;
            }

            // Parse retry policy
            var retryPolicy = ParseRetryPolicy(fullJob.RetryPolicyUsedJson);
            
            // Check if should retry
            if (job.Attempt < job.MaxRetry && 
                _retryPolicyService.ShouldRetry(job.Attempt + 1, retryPolicy))
            {
                // Calculate next retry time
                var delay = _retryPolicyService.CalculateDelay(job.Attempt + 1, retryPolicy);
                var nextRetryAt = DateTime.UtcNow.Add(delay);
                
                await runRepository.MarkAsRetryPendingAsync(job.RunId, nextRetryAt, ct);
                
                _logger.LogInformation("Marked run {RunId} as RETRY_PENDING, next retry at {NextRetryAt}", 
                    job.RunId, nextRetryAt);
            }
            else
            {
                // Max retries exceeded, mark as FAILED
                await runRepository.UpdateRunStatusAsync(
                    job.RunId,
                    JobRunStatus.Failed,
                    errorMessage: "Worker heartbeat lost and max retries exceeded",
                    ct: ct);
                
                _logger.LogWarning("Marked run {RunId} as FAILED (max retries exceeded)", job.RunId);
            }
        }
    }

    private static RetryPolicy ParseRetryPolicy(string? retryPolicyJson)
    {
        if (string.IsNullOrWhiteSpace(retryPolicyJson))
        {
            return new RetryPolicy(); // Default
        }

        try
        {
            var policy = System.Text.Json.JsonSerializer.Deserialize<RetryPolicy>(retryPolicyJson);
            return policy ?? new RetryPolicy();
        }
        catch
        {
            return new RetryPolicy();
        }
    }
}
