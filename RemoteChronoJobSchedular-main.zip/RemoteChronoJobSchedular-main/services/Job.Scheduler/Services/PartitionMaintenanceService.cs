using JobScheduler.Data.Data;
using JobScheduler.Data.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;

namespace Job.Scheduler.Services;

#region Infrastructure Code - Partition Management
/// <summary>
/// INFRASTRUCTURE SERVICE - NOT part of job scheduling logic
/// 
/// Background service that maintains hourly partitions for job_run table.
/// This is a platform/infrastructure concern, not business logic.
/// 
/// Responsibilities:
/// - Creates future partitions (48 hours ahead)
/// - Drops old partitions (>30 days)
/// - Runs independently of job scheduling
/// 
/// Note: In production systems, this would typically be:
/// - A separate platform service, OR
/// - A database maintenance job (MySQL Event Scheduler / cron)
/// </summary>
public class PartitionMaintenanceService : BackgroundService
#endregion
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<PartitionMaintenanceService> _logger;
    private readonly TimeSpan _checkInterval = TimeSpan.FromHours(1); // Check every hour
    private readonly int _hoursAhead = 48; // Create partitions 48 hours ahead
    private readonly int _daysToKeep = 30; // Keep partitions for 30 days

    public PartitionMaintenanceService(
        IServiceProvider serviceProvider,
        ILogger<PartitionMaintenanceService> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("[INFRA] Partition Maintenance Service started. Will check every {Interval} hours", _checkInterval.TotalHours);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await MaintainPartitionsAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                // Infrastructure failures should not crash the scheduler
                _logger.LogError(ex, "[INFRA] Error in partition maintenance service (non-critical)");
            }

            // Wait before next check
            await Task.Delay(_checkInterval, stoppingToken);
        }

        _logger.LogInformation("[INFRA] Partition Maintenance Service stopped");
    }

    private async Task MaintainPartitionsAsync(CancellationToken ct)
    {
        using var scope = _serviceProvider.CreateScope();
        var configuration = scope.ServiceProvider.GetRequiredService<IConfiguration>();
        var connectionString = configuration.GetConnectionString("DefaultConnection");

        if (string.IsNullOrEmpty(connectionString))
        {
            _logger.LogWarning("Connection string not found, skipping partition maintenance");
            return;
        }

        var optionsBuilder = new DbContextOptionsBuilder<JobSchedulerDbContext>();
        optionsBuilder.UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 21)));

        using var context = new JobSchedulerDbContext(optionsBuilder.Options);
        var loggerFactory = scope.ServiceProvider.GetRequiredService<ILoggerFactory>();
        var partitionLogger = loggerFactory.CreateLogger<PartitionManager>();
        var partitionManager = new PartitionManager(context, partitionLogger);

            try
            {
                // Create future partitions
                _logger.LogInformation("[INFRA] Creating future partitions (next {Hours} hours)...", _hoursAhead);
                var created = await partitionManager.EnsureFuturePartitionsAsync(_hoursAhead, ct);
                if (created > 0)
                {
                    _logger.LogInformation("[INFRA] Created {Count} new partition(s)", created);
                }

                // Drop old partitions
                _logger.LogInformation("[INFRA] Dropping old partitions (keeping last {Days} days)...", _daysToKeep);
                var dropped = await partitionManager.DropOldPartitionsAsync(_daysToKeep, ct);
                if (dropped > 0)
                {
                    _logger.LogInformation("[INFRA] Dropped {Count} old partition(s)", dropped);
                }

                // Log partition count
                var partitions = await partitionManager.GetExistingPartitionsAsync(ct);
                _logger.LogInformation("[INFRA] Current partition count: {Count}", partitions.Count);
            }
            catch (Exception ex)
            {
                // Infrastructure failures are logged but don't affect job scheduling
                _logger.LogError(ex, "[INFRA] Error maintaining partitions (non-critical)");
            }
    }
}
