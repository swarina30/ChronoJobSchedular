using JobScheduler.Contracts.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Job.Scheduler.Services;

/// <summary>
/// Loop B: Dispatches PENDING runs to Redis queues
/// Runs continuously
/// </summary>
public class RunDispatcher : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<RunDispatcher> _logger;
    private readonly int _numQueues;
    private const int BatchSize = 5000;
    private const int DispatchIntervalMs = 100; // Check every 100ms

    public RunDispatcher(
        IServiceScopeFactory scopeFactory,
        ILogger<RunDispatcher> logger,
        IConfiguration configuration)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
        _numQueues = int.Parse(configuration["Queue:NumQueues"] ?? "16");
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("RunDispatcher started. Number of queues: {NumQueues}", _numQueues);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                await DispatchPendingRunsAsync(scope, stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in RunDispatcher loop");
            }

            await Task.Delay(TimeSpan.FromMilliseconds(DispatchIntervalMs), stoppingToken);
        }
    }

    private async Task DispatchPendingRunsAsync(IServiceScope scope, CancellationToken ct)
    {
        try
        {
            var runRepository = scope.ServiceProvider.GetRequiredService<IJobRunRepository>();
            var queueService = scope.ServiceProvider.GetRequiredService<IQueueService>();

            // Get pending runs ready for dispatch
            _logger.LogInformation("RunDispatcher: Querying for pending runs...");
            var pendingRuns = await runRepository.GetPendingRunsAsync(BatchSize, ct);
            _logger.LogInformation("RunDispatcher: Query returned {Count} runs", pendingRuns.Count);
            
            if (pendingRuns.Count == 0)
            {
                // Log occasionally to show the loop is running (every 10 seconds)
                if (DateTime.UtcNow.Second % 10 == 0)
                {
                    _logger.LogInformation("RunDispatcher: No pending runs found (loop is running)");
                }
                return; // No work to do
            }

        _logger.LogInformation("RunDispatcher: Found {Count} pending runs to dispatch", pendingRuns.Count);

        // Prepare batch updates: calculate queue IDs and prepare updates
        var queueUpdates = new List<(Guid RunId, int QueueId)>();
        var queuePushTasks = new List<Task>();

        foreach (var run in pendingRuns)
        {
            try
            {
                // Calculate queue ID using hash of run_id
                var queueId = CalculateQueueId(run.RunId);
                
                // Prepare batch update
                queueUpdates.Add((run.RunId, queueId));
                
                // Push to Redis queue (async, don't await individually)
                queuePushTasks.Add(queueService.PushAsync(queueId, run.RunId, ct));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error preparing dispatch for run {RunId}", run.RunId);
            }
        }

        // BATCH OPERATION: Update all runs to QUEUED in a single transaction
        var updatedCount = 0;
        if (queueUpdates.Count > 0)
        {
            updatedCount = await runRepository.BatchMarkAsQueuedAsync(queueUpdates, ct);
            _logger.LogDebug("Batch updated {Count} runs to QUEUED status", updatedCount);
        }

        // Wait for all Redis pushes to complete (or fail)
        try
        {
            await Task.WhenAll(queuePushTasks);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error pushing runs to Redis queues");
            // Note: Runs are already marked as QUEUED, so they'll be retried by workers
        }

        if (updatedCount > 0)
        {
            _logger.LogInformation("Dispatched {Count} runs to queues", updatedCount);
        }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in DispatchPendingRunsAsync");
            throw;
        }
    }

    private int CalculateQueueId(Guid runId)
    {
        // Hash run_id and modulo by number of queues
        var hash = runId.GetHashCode();
        return Math.Abs(hash) % _numQueues;
    }
}
