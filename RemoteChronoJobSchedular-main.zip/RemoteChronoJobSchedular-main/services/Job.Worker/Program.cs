using Job.Worker.Services;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Data.Data;
using JobScheduler.Data.Repositories;
using JobScheduler.Infrastructure.Queue;
using JobScheduler.Infrastructure.Redis;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;

var builder = Host.CreateApplicationBuilder(args);

// Database configuration
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

builder.Services.AddDbContext<JobSchedulerDbContext>(options =>
{
    var serverVersion = ServerVersion.Create(new Version(8, 0, 0), ServerType.MySql);
    options.UseMySql(connectionString, serverVersion);
});

// Repositories
builder.Services.AddScoped<IJobRunRepository, JobRunRepository>();
builder.Services.AddScoped<IJobDefinitionRepository, JobDefinitionRepository>();

// Redis
builder.Services.AddSingleton<JobScheduler.Infrastructure.Redis.RedisConnectionService>();
builder.Services.AddScoped<IQueueService, JobScheduler.Infrastructure.Queue.RedisQueueService>();
// IRedisHeartbeatService must be singleton because HeartbeatService (singleton) depends on it
builder.Services.AddSingleton<IRedisHeartbeatService, JobScheduler.Infrastructure.Redis.RedisHeartbeatService>();

// Worker services
// HeartbeatService is both a service (for QueueConsumer to inject) and a BackgroundService
builder.Services.AddSingleton<HeartbeatService>();
builder.Services.AddHostedService(provider => provider.GetRequiredService<HeartbeatService>());
builder.Services.AddScoped<JobExecutor>();
builder.Services.AddHostedService<QueueConsumer>();

// Logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

var host = builder.Build();
host.Run();
