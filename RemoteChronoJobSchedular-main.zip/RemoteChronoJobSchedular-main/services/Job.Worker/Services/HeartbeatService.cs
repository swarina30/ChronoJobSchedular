using JobScheduler.Contracts.Interfaces;
using Microsoft.Extensions.Logging;

namespace Job.Worker.Services;

/// <summary>
/// Heartbeat service that batch updates Redis ZSET every 5 seconds
/// </summary>
public class HeartbeatService : BackgroundService
{
    private readonly IRedisHeartbeatService _redisHeartbeatService;
    private readonly ILogger<HeartbeatService> _logger;
    private readonly HashSet<Guid> _trackedRunIds = new();
    private readonly object _lock = new();
    private const int HeartbeatIntervalSeconds = 5;

    public HeartbeatService(
        IRedisHeartbeatService redisHeartbeatService,
        ILogger<HeartbeatService> logger)
    {
        _redisHeartbeatService = redisHeartbeatService;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("HeartbeatService started");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await SendHeartbeatsAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in HeartbeatService loop");
            }

            await Task.Delay(TimeSpan.FromSeconds(HeartbeatIntervalSeconds), stoppingToken);
        }
    }

    private async Task SendHeartbeatsAsync(CancellationToken ct)
    {
        List<Guid> runIds;
        
        lock (_lock)
        {
            if (_trackedRunIds.Count == 0)
            {
                return; // No jobs to heartbeat
            }
            
            runIds = _trackedRunIds.ToList();
        }

        // Batch update all heartbeats in one Redis command
        await _redisHeartbeatService.BatchUpdateHeartbeatAsync(runIds, ct);
        
        _logger.LogDebug("Sent heartbeat for {Count} jobs", runIds.Count);
    }

    /// <summary>
    /// Start tracking a run ID (add to heartbeat list)
    /// </summary>
    public void StartTracking(Guid runId)
    {
        lock (_lock)
        {
            _trackedRunIds.Add(runId);
            _logger.LogDebug("Started tracking heartbeat for run {RunId}", runId);
        }
    }

    /// <summary>
    /// Stop tracking a run ID (remove from heartbeat list)
    /// </summary>
    public void StopTracking(Guid runId)
    {
        lock (_lock)
        {
            _trackedRunIds.Remove(runId);
            _logger.LogDebug("Stopped tracking heartbeat for run {RunId}", runId);
        }
    }
}
