using JobScheduler.Contracts.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Text.Json;

namespace Job.Worker.Services;

/// <summary>
/// Executes Python scripts (or other job types)
/// </summary>
public class JobExecutor
{
    private readonly ILogger<JobExecutor> _logger;
    private readonly string _pythonPath;

    public JobExecutor(ILogger<JobExecutor> logger, IConfiguration configuration)
    {
        _logger = logger;
        _pythonPath = configuration["Worker:PythonPath"] ?? "python3";
    }

    public async Task<ExecutionResult> ExecuteAsync(JobRun jobRun, CancellationToken ct)
    {
        _logger.LogInformation("Executing job run {RunId}", jobRun.RunId);

        // Get script content from job definition
        var scriptContent = jobRun.Job?.ScriptContent ?? throw new InvalidOperationException($"Job definition not found for run {jobRun.RunId}");
        var args = ParseArgs(jobRun.Job?.ArgsJson);
        var timeout = TimeSpan.FromSeconds(jobRun.Job?.TimeoutSeconds ?? 3600);

        try
        {
            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = _pythonPath,
                    Arguments = "-", // Read from stdin
                    RedirectStandardInput = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };

            var stdout = new List<string>();
            var stderr = new List<string>();

            process.OutputDataReceived += (sender, e) =>
            {
                if (!string.IsNullOrEmpty(e.Data))
                {
                    stdout.Add(e.Data);
                }
            };

            process.ErrorDataReceived += (sender, e) =>
            {
                if (!string.IsNullOrEmpty(e.Data))
                {
                    stderr.Add(e.Data);
                }
            };

            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            // Write script to stdin
            await process.StandardInput.WriteAsync(scriptContent);
            await process.StandardInput.FlushAsync();
            process.StandardInput.Close();

            // Wait with timeout
            var completed = await Task.Run(() => process.WaitForExit((int)timeout.TotalMilliseconds), ct);
            
            if (!completed)
            {
                process.Kill();
                return new ExecutionResult
                {
                    Success = false,
                    ErrorMessage = "Job execution timed out",
                    Stdout = string.Join("\n", stdout),
                    Stderr = string.Join("\n", stderr)
                };
            }

            await process.WaitForExitAsync(ct);

            var success = process.ExitCode == 0;
            var outputJson = JsonSerializer.Serialize(new { exitCode = process.ExitCode });

            return new ExecutionResult
            {
                Success = success,
                OutputJson = outputJson,
                ErrorMessage = success ? null : $"Process exited with code {process.ExitCode}",
                Stdout = string.Join("\n", stdout),
                Stderr = string.Join("\n", stderr)
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing job run {RunId}", jobRun.RunId);
            return new ExecutionResult
            {
                Success = false,
                ErrorMessage = ex.Message,
                Stdout = "",
                Stderr = ex.StackTrace ?? ""
            };
        }
    }

    private static Dictionary<string, object>? ParseArgs(string? argsJson)
    {
        if (string.IsNullOrWhiteSpace(argsJson))
        {
            return null;
        }

        try
        {
            return JsonSerializer.Deserialize<Dictionary<string, object>>(argsJson);
        }
        catch
        {
            return null;
        }
    }
}

/// <summary>
/// Execution result
/// </summary>
public class ExecutionResult
{
    public bool Success { get; set; }
    public string? OutputJson { get; set; }
    public string? ErrorMessage { get; set; }
    public string Stdout { get; set; } = string.Empty;
    public string Stderr { get; set; } = string.Empty;
}
