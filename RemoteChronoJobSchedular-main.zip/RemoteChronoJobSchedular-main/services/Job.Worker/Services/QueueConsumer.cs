using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Job.Worker.Services;

/// <summary>
/// Main worker service that consumes jobs from Redis queues
/// </summary>
public class QueueConsumer : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly HeartbeatService _heartbeatService;
    private readonly ILogger<QueueConsumer> _logger;
    private readonly int[] _queueIds; // All queues this worker listens to
    private readonly string _workerId;
    private const int PopTimeoutSeconds = 5;

    public QueueConsumer(
        IServiceScopeFactory scopeFactory,
        HeartbeatService heartbeatService,
        ILogger<QueueConsumer> logger,
        IConfiguration configuration)
    {
        _scopeFactory = scopeFactory;
        _heartbeatService = heartbeatService;
        _logger = logger;
        
        // Worker listens to ALL queues by default (can be configured)
        var numQueues = int.Parse(configuration["Queue:NumQueues"] ?? "16");
        var queueIdsStr = configuration["Worker:QueueIds"]; // Optional: comma-separated list
        
        if (!string.IsNullOrWhiteSpace(queueIdsStr))
        {
            // Specific queues configured
            _queueIds = queueIdsStr.Split(',', StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();
        }
        else
        {
            // Listen to all queues (default behavior)
            _queueIds = Enumerable.Range(0, numQueues).ToArray();
        }
        
        _workerId = configuration["Worker:WorkerId"] ?? Environment.MachineName;
        
        _logger.LogInformation("QueueConsumer configured. WorkerId: {WorkerId}, Listening to {Count} queues: {Queues}", 
            _workerId, _queueIds.Length, string.Join(", ", _queueIds));
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("QueueConsumer started. WorkerId: {WorkerId}, Listening to {Count} queues", 
            _workerId, _queueIds.Length);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var queueService = scope.ServiceProvider.GetRequiredService<IQueueService>();
                
                // Blocking pop from multiple queues - gets job from whichever queue has data first
                _logger.LogDebug("QueueConsumer: Attempting to pop from {Count} queues", _queueIds.Length);
                var result = await queueService.PopFromMultipleQueuesAsync(_queueIds, PopTimeoutSeconds, stoppingToken);
                
                if (result.HasValue)
                {
                    var queueId = result.Value.QueueId;
                    var runId = result.Value.RunId;
                    _logger.LogInformation("QueueConsumer: Popped run {RunId} from queue {QueueId}", runId, queueId);
                    
                    // Process job asynchronously (don't await to allow parallel processing)
                    // Create new scope for each job processing
                    _ = Task.Run(async () => 
                    {
                        using var jobScope = _scopeFactory.CreateScope();
                        await ProcessJobAsync(jobScope, runId, stoppingToken);
                    }, stoppingToken);
                }
                else
                {
                    _logger.LogDebug("QueueConsumer: No job found in any queue (timeout: {Timeout}s)", PopTimeoutSeconds);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in QueueConsumer loop");
                await Task.Delay(TimeSpan.FromSeconds(1), stoppingToken);
            }
        }
    }

    private async Task ProcessJobAsync(IServiceScope scope, Guid runId, CancellationToken ct)
    {
        try
        {
            _logger.LogInformation("Processing job run {RunId}", runId);

            var runRepository = scope.ServiceProvider.GetRequiredService<IJobRunRepository>();
            var jobExecutor = scope.ServiceProvider.GetRequiredService<JobExecutor>();

            // CAS update: Try to claim the job (QUEUED → RUNNING)
            var claimed = await runRepository.TryClaimRunAsync(runId, _workerId, ct);
            
            if (!claimed)
            {
                _logger.LogWarning("Failed to claim run {RunId} - already claimed by another worker", runId);
                return; // Another worker already claimed it
            }

            // Get full job run details (includes job definition)
            var jobRun = await runRepository.GetByIdAsync(runId, ct);
            if (jobRun == null || jobRun.Job == null)
            {
                _logger.LogError("Job run {RunId} or job definition not found after claiming", runId);
                return;
            }
            
            // Start heartbeat tracking
            _heartbeatService.StartTracking(runId);
            
            try
            {
                // Execute the job
                var result = await jobExecutor.ExecuteAsync(jobRun, ct);
                
                // Update final status
                await runRepository.UpdateRunStatusAsync(
                    runId,
                    result.Success ? JobRunStatus.Completed : JobRunStatus.Failed,
                    outputJson: result.OutputJson,
                    errorMessage: result.ErrorMessage,
                    stdout: result.Stdout,
                    stderr: result.Stderr,
                    ct: ct);
                
                _logger.LogInformation("Job run {RunId} completed with status: {Status}", 
                    runId, result.Success ? "COMPLETED" : "FAILED");
            }
            finally
            {
                // Stop heartbeat tracking
                _heartbeatService.StopTracking(runId);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing job run {RunId}", runId);
            
            // Mark as failed
            try
            {
                using var errorScope = _scopeFactory.CreateScope();
                var errorRunRepository = errorScope.ServiceProvider.GetRequiredService<IJobRunRepository>();
                await errorRunRepository.UpdateRunStatusAsync(
                    runId,
                    JobRunStatus.Failed,
                    errorMessage: ex.Message,
                    ct: ct);
            }
            catch (Exception updateEx)
            {
                _logger.LogError(updateEx, "Failed to update status for run {RunId}", runId);
            }
        }
    }
}
