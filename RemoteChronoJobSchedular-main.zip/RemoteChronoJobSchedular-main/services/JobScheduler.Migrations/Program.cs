using JobScheduler.Data.Data;
using JobScheduler.Data.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;

namespace JobScheduler.Migrations;

/// <summary>
/// Migration service for managing database migrations and partitions
/// </summary>
class Program
{
    static async Task Main(string[] args)
    {
        Console.WriteLine("Job Scheduler - Migration Service");
        Console.WriteLine("=================================");

        // Load configuration (env vars override appsettings, e.g. in Docker)
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
            .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development"}.json", optional: true)
            .AddEnvironmentVariables()
            .Build();

        var connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found. Set ConnectionStrings__DefaultConnection in appsettings.json or environment.");

        Console.WriteLine($"Connection: {connectionString.Split(';').FirstOrDefault()}");

        // Create DbContext options
        var optionsBuilder = new DbContextOptionsBuilder<JobSchedulerDbContext>();
        optionsBuilder.UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 21)), options =>
        {
            options.EnableRetryOnFailure();
        });

        using var context = new JobSchedulerDbContext(optionsBuilder.Options);

        // Create logger factory for PartitionManager
        using var loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
        var logger = loggerFactory.CreateLogger<PartitionManager>();
        var partitionManager = new PartitionManager(context, logger);

        try
        {
            // Check database connection
            Console.WriteLine("Checking database connection...");
            var canConnect = await context.Database.CanConnectAsync();
            Console.WriteLine($"Database connection: {(canConnect ? "OK" : "FAILED")}");

            if (!canConnect)
            {
                Console.WriteLine("Creating database...");
                await context.Database.EnsureCreatedAsync();
                Console.WriteLine("Database created successfully.");
            }

            // Setup partitioned job_run table
            Console.WriteLine("\nSetting up partitioned job_run table...");
            await SetupPartitionedTableAsync(context);
            Console.WriteLine("Partitioned table setup completed.");

            // Create initial partitions (next 48 hours)
            Console.WriteLine("\nCreating initial hourly partitions (next 48 hours)...");
            var partitionsCreated = await partitionManager.EnsureFuturePartitionsAsync(48);
            Console.WriteLine($"Created {partitionsCreated} partition(s).");

            // List existing partitions
            var existingPartitions = await partitionManager.GetExistingPartitionsAsync();
            if (existingPartitions.Any())
            {
                Console.WriteLine($"\nExisting partitions ({existingPartitions.Count}):");
                foreach (var (name, start, end) in existingPartitions.Take(10))
                {
                    Console.WriteLine($"  - {name}: {start:yyyy-MM-dd HH:mm} to {end:yyyy-MM-dd HH:mm}");
                }
                if (existingPartitions.Count > 10)
                {
                    Console.WriteLine($"  ... and {existingPartitions.Count - 10} more");
                }
            }

            // Check pending migrations
            var pendingMigrations = await context.Database.GetPendingMigrationsAsync();
            var pendingList = pendingMigrations.ToList();

            if (pendingList.Any())
            {
                Console.WriteLine($"\nFound {pendingList.Count} pending migration(s):");
                foreach (var migration in pendingList)
                {
                    Console.WriteLine($"  - {migration}");
                }
            }
            else
            {
                Console.WriteLine("\nNo pending migrations.");
            }

            // Check applied migrations
            var appliedMigrations = await context.Database.GetAppliedMigrationsAsync();
            var appliedList = appliedMigrations.ToList();

            if (appliedList.Any())
            {
                Console.WriteLine($"\nApplied migrations ({appliedList.Count}):");
                foreach (var migration in appliedList)
                {
                    Console.WriteLine($"  - {migration}");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\nError: {ex.Message}");
            Console.WriteLine(ex.StackTrace);
            Environment.Exit(1);
        }

        Console.WriteLine("\nMigration service completed.");
    }

    private static async Task SetupPartitionedTableAsync(JobSchedulerDbContext context)
    {
        await context.Database.OpenConnectionAsync();
        try
        {
            // Check if job_run table exists
            using var checkCommand = context.Database.GetDbConnection().CreateCommand();
            checkCommand.CommandText = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'job_run'";
            var tableExists = Convert.ToInt32(await checkCommand.ExecuteScalarAsync()) > 0;

            // If table exists, check if it's partitioned
            if (tableExists)
            {
                var isPartitioned = await CheckIfPartitionedAsync(context);
                if (isPartitioned)
                {
                    Console.WriteLine("  job_run table is already partitioned.");
                    return;
                }
                else
                {
                    Console.WriteLine("  WARNING: job_run table exists but is not partitioned.");
                    Console.WriteLine("  Dropping existing table to recreate with partitions...");
                    // Drop the non-partitioned table
                    await context.Database.ExecuteSqlRawAsync("DROP TABLE IF EXISTS job_run");
                    Console.WriteLine("  Dropped existing job_run table.");
                }
            }
        }
        finally
        {
            await context.Database.CloseConnectionAsync();
        }

        // Create partitioned table with at least one initial partition
        // MySQL requires at least one partition when creating a RANGE partitioned table
        var now = DateTime.UtcNow;
        var currentHour = new DateTime(now.Year, now.Month, now.Day, now.Hour, 0, 0, DateTimeKind.Utc);
        var nextHour = currentHour.AddHours(1);
        var currentHourTimestamp = ((DateTimeOffset)currentHour).ToUnixTimeSeconds();
        var nextHourTimestamp = ((DateTimeOffset)nextHour).ToUnixTimeSeconds();
        var partitionName = $"p_{currentHour:yyyyMMdd}_{currentHour:HH}";

        var createTableSql = $@"
            CREATE TABLE job_run (
                run_id CHAR(36) NOT NULL,
                scheduled_at TIMESTAMP NOT NULL,
                job_id CHAR(36) NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'CREATED',
                attempt INT NOT NULL DEFAULT 0,
                max_retry INT NOT NULL DEFAULT 3,
                queue_id INT NOT NULL,
                worker_id VARCHAR(100) NULL,
                server_id VARCHAR(100) NULL,
                started_at TIMESTAMP NULL,
                finished_at TIMESTAMP NULL,
                execution_duration_ms BIGINT NULL,
                output_json JSON NULL,
                error_message TEXT NULL,
                stdout TEXT NULL,
                stderr TEXT NULL,
                retry_policy_used_json JSON NULL,
                next_retry_at TIMESTAMP NULL,
                version INT NOT NULL DEFAULT 1,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                last_replicated_at TIMESTAMP NULL,
                replication_version BIGINT NULL,
                PRIMARY KEY (run_id, scheduled_at),
                INDEX idx_run_status_time (status, scheduled_at),
                INDEX idx_run_queue (queue_id, status),
                INDEX idx_run_job_id (job_id),
                INDEX idx_run_worker (worker_id),
                INDEX idx_run_replication (replication_version)
                -- Note: Foreign keys are not supported on partitioned tables in MySQL
                -- Foreign key relationship is enforced at application level
            ) PARTITION BY RANGE (UNIX_TIMESTAMP(scheduled_at)) (
                PARTITION {partitionName} VALUES LESS THAN ({nextHourTimestamp})
            )";

        try
        {
            await context.Database.ExecuteSqlRawAsync(createTableSql);
            Console.WriteLine($"  Created partitioned job_run table with initial partition {partitionName}.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"  Error creating partitioned table: {ex.Message}");
            throw;
        }
    }

    private static async Task<bool> CheckIfPartitionedAsync(JobSchedulerDbContext context)
    {
        await context.Database.OpenConnectionAsync();
        try
        {
            using var command = context.Database.GetDbConnection().CreateCommand();
            command.CommandText = @"
                SELECT COUNT(*)
                FROM INFORMATION_SCHEMA.PARTITIONS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = 'job_run'
                AND PARTITION_NAME IS NOT NULL";

            var result = await command.ExecuteScalarAsync();
            return Convert.ToInt32(result) > 0;
        }
        finally
        {
            await context.Database.CloseConnectionAsync();
        }
    }
}
