#!/bin/bash

# Setup script for Job Scheduler

set -e

echo "🚀 Setting up Job Scheduler..."

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker Desktop."
    exit 1
fi

echo "✅ Docker is running"

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p docker/mysql/data
mkdir -p docker/mysql/init

# Start infrastructure
echo "🐳 Starting MySQL and Redis..."
docker-compose up -d mysql redis

# Wait for MySQL to be healthy
echo "⏳ Waiting for MySQL to be ready..."
timeout=60
counter=0
while ! docker exec job-scheduler-mysql mysqladmin ping -h localhost -u root -proot --silent 2>/dev/null; do
    sleep 2
    counter=$((counter + 2))
    if [ $counter -ge $timeout ]; then
        echo "❌ MySQL failed to start within $timeout seconds"
        exit 1
    fi
done

echo "✅ MySQL is ready"

# Wait for Redis to be healthy
echo "⏳ Waiting for Redis to be ready..."
timeout=30
counter=0
while ! docker exec job-scheduler-redis redis-cli ping > /dev/null 2>&1; do
    sleep 1
    counter=$((counter + 1))
    if [ $counter -ge $timeout ]; then
        echo "❌ Redis failed to start within $timeout seconds"
        exit 1
    fi
done

echo "✅ Redis is ready"

# Run migrations
echo "🗄️ Running database migrations..."
docker-compose run --rm migrations || {
    echo "⚠️ Migrations service not available, skipping..."
}

echo ""
echo "✅ Setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Start all services: docker-compose up -d"
echo "2. View logs: docker-compose logs -f"
echo "3. Access API: http://localhost:5136/swagger"
echo "4. Access Monitor: http://localhost:5137/swagger"
echo ""
echo "To stop all services: docker-compose down"
