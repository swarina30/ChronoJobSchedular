using JobScheduler.Contracts.Enums;

namespace JobScheduler.Contracts.Entities;

/// <summary>
/// Job definition entity (cold table)
/// </summary>
public class JobDefinition
{
    public Guid JobId { get; set; }
    public Guid UserId { get; set; }
    public Guid CreatedBy { get; set; }
    public Guid? UpdatedBy { get; set; }
    
    public JobType JobType { get; set; }
    public string? CronExpr { get; set; }
    public string ScriptContent { get; set; } = string.Empty; // Python script content stored in DB
    public string? ArgsJson { get; set; }
    public string? RetryPolicyJson { get; set; }
    public int? TimeoutSeconds { get; set; } = 3600;
    
    public JobStatus Status { get; set; } = JobStatus.Created;
    
    // Scaling attributes
    public string? ServerId { get; set; }
    public int Version { get; set; } = 1;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? DeletedAt { get; set; }
    
    // Replication metadata
    public DateTime? LastReplicatedAt { get; set; }
    public long? ReplicationVersion { get; set; }
    
    // Navigation properties (EF Core)
    public JobScheduleState? ScheduleState { get; set; }
    public List<JobRun> Runs { get; set; } = new();
}
