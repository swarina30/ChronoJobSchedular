using JobScheduler.Contracts.Enums;

namespace JobScheduler.Contracts.Entities;

/// <summary>
/// Job run entity (hot, partitioned)
/// </summary>
public class JobRun
{
    public Guid RunId { get; set; }
    public DateTime ScheduledAt { get; set; }
    public Guid JobId { get; set; }
    
    public JobRunStatus Status { get; set; } = JobRunStatus.Created;
    public int Attempt { get; set; } = 0;
    public int MaxRetry { get; set; } = 3;
    public int QueueId { get; set; }
    public string? WorkerId { get; set; }
    public string? ServerId { get; set; }
    
    public DateTime? StartedAt { get; set; }
    public DateTime? FinishedAt { get; set; }
    public long? ExecutionDurationMs { get; set; }
    
    public string? OutputJson { get; set; }
    public string? ErrorMessage { get; set; }
    public string? Stdout { get; set; }
    public string? Stderr { get; set; }
    
    public string? RetryPolicyUsedJson { get; set; }
    public DateTime? NextRetryAt { get; set; }
    
    // Scaling attributes
    public int Version { get; set; } = 1;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    
    // Replication metadata
    public DateTime? LastReplicatedAt { get; set; }
    public long? ReplicationVersion { get; set; }
    
    // Navigation property
    public JobDefinition Job { get; set; } = null!;
}
