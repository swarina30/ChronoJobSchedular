namespace JobScheduler.Contracts.Entities;

/// <summary>
/// Job schedule state entity (hot but bounded)
/// </summary>
public class JobScheduleState
{
    public Guid JobId { get; set; }
    public DateTime LastScheduledAt { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? NextRunAt { get; set; }
    
    // Scaling attributes
    public string? SchedulerId { get; set; }
    public int Version { get; set; } = 1;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    
    // Replication metadata
    public DateTime? LastReplicatedAt { get; set; }
    public long? ReplicationVersion { get; set; }
    
    // Navigation property
    public JobDefinition Job { get; set; } = null!;
}
