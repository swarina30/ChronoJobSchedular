using JobScheduler.Contracts.Enums;

namespace JobScheduler.Contracts.Entities;

/// <summary>
/// User entity for authentication and authorization
/// </summary>
public class User
{
    public Guid UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    
    public UserRole Role { get; set; } = UserRole.User;
    public bool IsActive { get; set; } = true;
    
    // Audit
    public Guid? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? LastLoginAt { get; set; }
    
    // Scaling attributes
    public int Version { get; set; } = 1;
    
    // Replication metadata
    public DateTime? LastReplicatedAt { get; set; }
    public long? ReplicationVersion { get; set; }
}
