namespace JobScheduler.Contracts.Enums;

/// <summary>
/// Status of a job run (execution instance)
/// </summary>
public enum JobRunStatus
{
    /// <summary>
    /// Run has been created
    /// </summary>
    Created = 1,
    
    /// <summary>
    /// Run is pending execution (waiting for scheduled time)
    /// </summary>
    Pending = 2,
    
    /// <summary>
    /// Run has been queued and waiting for worker
    /// </summary>
    Queued = 3,
    
    /// <summary>
    /// Run is currently executing
    /// </summary>
    Running = 4,
    
    /// <summary>
    /// Run completed successfully
    /// </summary>
    Completed = 5,
    
    /// <summary>
    /// Run failed after all retry attempts
    /// </summary>
    Failed = 6,
    
    /// <summary>
    /// Run is pending retry
    /// </summary>
    RetryPending = 7,
    
    /// <summary>
    /// Run timed out
    /// </summary>
    Timeout = 8,
    
    /// <summary>
    /// Run was cancelled
    /// </summary>
    Cancelled = 9
}
