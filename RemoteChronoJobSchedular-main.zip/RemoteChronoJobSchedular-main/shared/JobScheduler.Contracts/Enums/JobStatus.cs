namespace JobScheduler.Contracts.Enums;

/// <summary>
/// Status of a job definition
/// </summary>
public enum JobStatus
{
    /// <summary>
    /// Job has been created but not yet activated
    /// </summary>
    Created = 1,
    
    /// <summary>
    /// Job is active and scheduled for execution
    /// </summary>
    Active = 2,
    
    /// <summary>
    /// Job is temporarily paused
    /// </summary>
    Paused = 3,
    
    /// <summary>
    /// Job has expired (one-time jobs only)
    /// </summary>
    Expired = 4,
    
    /// <summary>
    /// Job has been deleted (soft delete)
    /// </summary>
    Deleted = 5
}
