namespace JobScheduler.Contracts.Enums;

/// <summary>
/// Type of job execution
/// </summary>
public enum JobType
{
    /// <summary>
    /// One-time job that executes once
    /// </summary>
    OneTime = 1,
    
    /// <summary>
    /// Recurring job that executes on a schedule (cron)
    /// </summary>
    Recurring = 2
}
