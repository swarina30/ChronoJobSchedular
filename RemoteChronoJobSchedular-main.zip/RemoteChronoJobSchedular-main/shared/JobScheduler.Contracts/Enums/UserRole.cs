namespace JobScheduler.Contracts.Enums;

/// <summary>
/// User role for authorization
/// </summary>
public enum UserRole
{
    /// <summary>
    /// Admin role - full access to all operations
    /// </summary>
    Admin = 1,
    
    /// <summary>
    /// User role - can manage own jobs
    /// </summary>
    User = 2,
    
    /// <summary>
    /// Viewer role - read-only access to own jobs
    /// </summary>
    Viewer = 3
}
