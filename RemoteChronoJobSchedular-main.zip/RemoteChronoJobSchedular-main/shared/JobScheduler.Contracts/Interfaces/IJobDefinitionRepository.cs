using JobScheduler.Contracts.Entities;

namespace JobScheduler.Contracts.Interfaces;

/// <summary>
/// Repository interface for JobDefinition operations
/// </summary>
public interface IJobDefinitionRepository
{
    /// <summary>
    /// Get job definition by ID
    /// </summary>
    Task<JobDefinition?> GetByIdAsync(Guid jobId, CancellationToken ct = default);
    
    /// <summary>
    /// Get job definition by ID including deleted records (for admin)
    /// </summary>
    Task<JobDefinition?> GetByIdIncludingDeletedAsync(Guid jobId, CancellationToken ct = default);
    
    /// <summary>
    /// Create new job definition
    /// </summary>
    Task<JobDefinition> CreateAsync(JobDefinition job, CancellationToken ct = default);
    
    /// <summary>
    /// Update job definition with optimistic locking
    /// </summary>
    /// <param name="job">Job to update</param>
    /// <param name="expectedVersion">Expected version for optimistic locking</param>
    Task<JobDefinition> UpdateAsync(JobDefinition job, int expectedVersion, CancellationToken ct = default);
    
    /// <summary>
    /// Soft delete job definition
    /// </summary>
    Task<bool> DeleteAsync(Guid jobId, Guid deletedBy, CancellationToken ct = default);
    
    /// <summary>
    /// Get paged jobs by user ID
    /// </summary>
    Task<PagedResult<JobDefinition>> GetByUserIdAsync(
        Guid userId, 
        int page, 
        int pageSize, 
        bool includeDeleted = false,
        CancellationToken ct = default);
    
    /// <summary>
    /// Get active recurring jobs (for scheduler)
    /// </summary>
    Task<List<JobDefinition>> GetActiveRecurringJobsAsync(CancellationToken ct = default);
}

/// <summary>
/// Paged result wrapper
/// </summary>
public class PagedResult<T>
{
    public List<T> Items { get; set; } = new();
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
}
