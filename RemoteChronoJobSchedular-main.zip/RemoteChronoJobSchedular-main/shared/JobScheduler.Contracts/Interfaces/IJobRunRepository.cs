using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Enums;

namespace JobScheduler.Contracts.Interfaces;

/// <summary>
/// Repository interface for JobRun operations
/// </summary>
public interface IJobRunRepository
{
    /// <summary>
    /// Create a new job run
    /// </summary>
    Task<JobRun> CreateAsync(JobRun jobRun, CancellationToken ct = default);
    
    /// <summary>
    /// Get job run by ID
    /// </summary>
    Task<JobRun?> GetByIdAsync(Guid runId, CancellationToken ct = default);
    
    /// <summary>
    /// Get pending runs ready for dispatch (scheduled_at <= now)
    /// </summary>
    Task<List<JobRun>> GetPendingRunsAsync(int limit = 5000, CancellationToken ct = default);
    
    /// <summary>
    /// Get running jobs (for heartbeat monitoring)
    /// </summary>
    Task<List<JobRun>> GetRunningJobsAsync(CancellationToken ct = default);
    
    /// <summary>
    /// CAS update: Update status from QUEUED to RUNNING (prevents duplicate execution)
    /// </summary>
    /// <returns>True if update succeeded, false if already claimed</returns>
    Task<bool> TryClaimRunAsync(Guid runId, string workerId, CancellationToken ct = default);
    
    /// <summary>
    /// Update job run status and execution details
    /// </summary>
    Task<JobRun> UpdateRunStatusAsync(
        Guid runId, 
        JobRunStatus status, 
        string? outputJson = null,
        string? errorMessage = null,
        string? stdout = null,
        string? stderr = null,
        CancellationToken ct = default);
    
    /// <summary>
    /// Update job run to QUEUED status (for dispatch)
    /// </summary>
    Task<bool> MarkAsQueuedAsync(Guid runId, int queueId, CancellationToken ct = default);
    
    /// <summary>
    /// Update job run to RETRY_PENDING with next retry time
    /// </summary>
    Task<bool> MarkAsRetryPendingAsync(Guid runId, DateTime nextRetryAt, CancellationToken ct = default);
    
    /// <summary>
    /// Get pending run counts grouped by job_id (batch operation)
    /// </summary>
    Task<Dictionary<Guid, int>> GetPendingRunCountsByJobIdAsync(CancellationToken ct = default);
    
    /// <summary>
    /// Batch create multiple job runs in a single transaction
    /// </summary>
    Task BatchCreateAsync(List<JobRun> jobRuns, CancellationToken ct = default);
    
    /// <summary>
    /// Batch update job runs to QUEUED status
    /// </summary>
    Task<int> BatchMarkAsQueuedAsync(List<(Guid RunId, int QueueId)> updates, CancellationToken ct = default);
    
    /// <summary>
    /// Get job runs by job ID (for viewing execution history)
    /// </summary>
    Task<PagedResult<JobRun>> GetRunsByJobIdAsync(Guid jobId, int page, int pageSize, CancellationToken ct = default);
    
    /// <summary>
    /// Cancel all PENDING and QUEUED runs for a job (standard practice: cancel pending, let running complete)
    /// </summary>
    Task<int> CancelPendingRunsForJobAsync(Guid jobId, CancellationToken ct = default);
}
