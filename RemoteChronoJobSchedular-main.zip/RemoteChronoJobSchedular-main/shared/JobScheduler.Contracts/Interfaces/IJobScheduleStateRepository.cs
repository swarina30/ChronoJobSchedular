using JobScheduler.Contracts.Entities;

namespace JobScheduler.Contracts.Interfaces;

/// <summary>
/// Repository interface for JobScheduleState operations
/// </summary>
public interface IJobScheduleStateRepository
{
    /// <summary>
    /// Get active recurring jobs
    /// </summary>
    Task<List<JobScheduleState>> GetActiveRecurringJobsAsync(CancellationToken ct = default);
    
    /// <summary>
    /// Get or create schedule state for a job
    /// </summary>
    Task<JobScheduleState> GetOrCreateAsync(Guid jobId, CancellationToken ct = default);
    
    /// <summary>
    /// Update last scheduled time
    /// </summary>
    Task UpdateLastScheduledAtAsync(Guid jobId, DateTime lastScheduledAt, DateTime? nextRunAt = null, CancellationToken ct = default);
    
    /// <summary>
    /// Deactivate schedule state (when job is paused/deleted)
    /// </summary>
    Task DeactivateAsync(Guid jobId, CancellationToken ct = default);
    
    /// <summary>
    /// Activate schedule state (when job is resumed)
    /// </summary>
    Task ActivateAsync(Guid jobId, CancellationToken ct = default);
    
    /// <summary>
    /// Batch update last scheduled at for multiple jobs
    /// </summary>
    Task BatchUpdateLastScheduledAtAsync(List<(Guid JobId, DateTime LastScheduledAt, DateTime? NextRunAt)> updates, CancellationToken ct = default);
}
