namespace JobScheduler.Contracts.Interfaces;

/// <summary>
/// Queue service interface for job dispatch
/// </summary>
public interface IQueueService
{
    /// <summary>
    /// Push run ID to a specific queue
    /// </summary>
    /// <param name="queueId">Queue identifier (0 to N-1)</param>
    /// <param name="runId">Job run ID to push</param>
    Task PushAsync(int queueId, Guid runId, CancellationToken ct = default);
    
    /// <summary>
    /// Pop run ID from a specific queue (blocking)
    /// </summary>
    /// <param name="queueId">Queue identifier</param>
    /// <param name="timeoutSeconds">Timeout in seconds (0 = no timeout)</param>
    /// <returns>Run ID if available, null if timeout</returns>
    Task<Guid?> PopAsync(int queueId, int timeoutSeconds = 0, CancellationToken ct = default);
    
    /// <summary>
    /// Get queue length
    /// </summary>
    Task<long> GetLengthAsync(int queueId, CancellationToken ct = default);
    
    /// <summary>
    /// Blocking pop from multiple queues - returns job from whichever queue has data first
    /// Returns (QueueId, RunId) or null if timeout
    /// </summary>
    Task<(int QueueId, Guid RunId)?> PopFromMultipleQueuesAsync(int[] queueIds, int timeoutSeconds = 5, CancellationToken ct = default);
}
