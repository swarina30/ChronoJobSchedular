namespace JobScheduler.Contracts.Interfaces;

/// <summary>
/// Redis heartbeat service for tracking running jobs (ZSET operations)
/// </summary>
public interface IRedisHeartbeatService
{
    /// <summary>
    /// Batch update heartbeats for multiple run IDs
    /// </summary>
    /// <param name="runIds">List of run IDs to update</param>
    Task BatchUpdateHeartbeatAsync(List<Guid> runIds, CancellationToken ct = default);
    
    /// <summary>
    /// Get all active run IDs from ZSET
    /// </summary>
    /// <returns>Set of active run IDs</returns>
    Task<HashSet<Guid>> GetActiveRunIdsAsync(CancellationToken ct = default);
    
    /// <summary>
    /// Remove stale entries from ZSET (older than threshold)
    /// </summary>
    /// <param name="staleThresholdSeconds">Entries older than this will be removed</param>
    Task CleanupStaleEntriesAsync(int staleThresholdSeconds = 60, CancellationToken ct = default);
    
    /// <summary>
    /// Remove specific run ID from ZSET
    /// </summary>
    Task RemoveRunIdAsync(Guid runId, CancellationToken ct = default);
}
