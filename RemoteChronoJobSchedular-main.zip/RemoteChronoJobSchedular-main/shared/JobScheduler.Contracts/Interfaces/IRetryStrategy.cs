using JobScheduler.Contracts.Models;

namespace JobScheduler.Contracts.Interfaces;

/// <summary>
/// Strategy pattern interface for retry delay calculation
/// </summary>
public interface IRetryStrategy
{
    /// <summary>
    /// Calculate delay before next retry attempt
    /// </summary>
    /// <param name="attempt">Current attempt number (1-based)</param>
    /// <param name="policy">Retry policy configuration</param>
    /// <returns>Delay duration</returns>
    TimeSpan CalculateDelay(int attempt, RetryPolicy policy);
    
    /// <summary>
    /// Check if retry should be attempted
    /// </summary>
    /// <param name="attempt">Current attempt number</param>
    /// <param name="maxAttempts">Maximum allowed attempts</param>
    /// <param name="exception">Exception that occurred (optional)</param>
    /// <returns>True if should retry</returns>
    bool ShouldRetry(int attempt, int maxAttempts, Exception? exception = null);
}
