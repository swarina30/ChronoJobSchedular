using JobScheduler.Contracts.Entities;

namespace JobScheduler.Contracts.Interfaces;

/// <summary>
/// Repository interface for User operations
/// </summary>
public interface IUserRepository
{
    /// <summary>
    /// Create a new user
    /// </summary>
    Task<User> CreateAsync(User user, CancellationToken ct = default);
    
    /// <summary>
    /// Get user by email
    /// </summary>
    Task<User?> GetByEmailAsync(string email, CancellationToken ct = default);
    
    /// <summary>
    /// Get user by ID
    /// </summary>
    Task<User?> GetByIdAsync(Guid userId, CancellationToken ct = default);
    
    /// <summary>
    /// Check if email exists
    /// </summary>
    Task<bool> EmailExistsAsync(string email, CancellationToken ct = default);
    
    /// <summary>
    /// Check if username exists
    /// </summary>
    Task<bool> UsernameExistsAsync(string username, CancellationToken ct = default);
    
    /// <summary>
    /// Update last login time
    /// </summary>
    Task UpdateLastLoginAsync(Guid userId, CancellationToken ct = default);
}
