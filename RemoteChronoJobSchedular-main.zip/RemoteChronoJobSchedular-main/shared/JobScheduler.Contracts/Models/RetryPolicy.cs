namespace JobScheduler.Contracts.Models;

/// <summary>
/// Retry policy configuration for job execution
/// </summary>
public class RetryPolicy
{
    /// <summary>
    /// Maximum number of retry attempts
    /// </summary>
    public int MaxAttempts { get; set; } = 3;
    
    /// <summary>
    /// Type of retry strategy (Exponential, Linear, Fixed)
    /// </summary>
    public string Strategy { get; set; } = "ExponentialBackoff";
    
    /// <summary>
    /// Initial delay in seconds before first retry
    /// </summary>
    public int InitialDelaySeconds { get; set; } = 5;
    
    /// <summary>
    /// Maximum delay in seconds between retries
    /// </summary>
    public int MaxDelaySeconds { get; set; } = 300;
    
    /// <summary>
    /// Multiplier for exponential backoff (default 2.0)
    /// </summary>
    public double Multiplier { get; set; } = 2.0;
}
