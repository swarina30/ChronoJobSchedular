using JobScheduler.Contracts.Entities;
using Microsoft.EntityFrameworkCore;

namespace JobScheduler.Data.Data;

/// <summary>
/// EF Core DbContext for Job Scheduler
/// </summary>
public class JobSchedulerDbContext : DbContext
{
    public JobSchedulerDbContext(DbContextOptions<JobSchedulerDbContext> options)
        : base(options)
    {
    }

    public DbSet<JobDefinition> JobDefinitions { get; set; } = null!;
    public DbSet<JobScheduleState> JobScheduleStates { get; set; } = null!;
    public DbSet<JobRun> JobRuns { get; set; } = null!;
    public DbSet<User> Users { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // JobDefinition configuration
        modelBuilder.Entity<JobDefinition>(entity =>
        {
            entity.ToTable("job_definition");
            entity.HasKey(e => e.JobId);
            entity.Property(e => e.JobId).HasColumnName("job_id");
            entity.Property(e => e.UserId).HasColumnName("user_id").IsRequired();
            entity.Property(e => e.CreatedBy).HasColumnName("created_by").IsRequired();
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            
            entity.Property(e => e.JobType).HasColumnName("job_type").HasConversion<string>().HasMaxLength(20).IsRequired();
            entity.Property(e => e.CronExpr).HasColumnName("cron_expr");
            entity.Property(e => e.ScriptContent).HasColumnName("script_content").IsRequired();
            entity.Property(e => e.ArgsJson).HasColumnName("args_json");
            entity.Property(e => e.RetryPolicyJson).HasColumnName("retry_policy_json");
            entity.Property(e => e.TimeoutSeconds).HasColumnName("timeout_seconds");
            
            entity.Property(e => e.Status).HasColumnName("status").HasConversion<string>().HasMaxLength(20).IsRequired();
            
            entity.Property(e => e.ServerId).HasColumnName("server_id").HasMaxLength(100);
            entity.Property(e => e.Version).HasColumnName("version").IsRequired();
            entity.Property(e => e.CreatedAt).HasColumnName("created_at").IsRequired();
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at").IsRequired();
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            
            entity.Property(e => e.LastReplicatedAt).HasColumnName("last_replicated_at");
            entity.Property(e => e.ReplicationVersion).HasColumnName("replication_version");

            // Indexes
            entity.HasIndex(e => e.UserId).HasFilter("[deleted_at] IS NULL").HasDatabaseName("idx_job_definition_user");
            entity.HasIndex(e => e.Status).HasFilter("[deleted_at] IS NULL").HasDatabaseName("idx_job_definition_status");
            entity.HasIndex(e => e.CreatedAt).HasDatabaseName("idx_job_definition_created_at");

            // Navigation properties
            entity.HasOne(e => e.ScheduleState)
                  .WithOne(s => s.Job)
                  .HasForeignKey<JobScheduleState>(s => s.JobId)
                  .OnDelete(DeleteBehavior.Cascade);

            entity.HasMany(e => e.Runs)
                  .WithOne(r => r.Job)
                  .HasForeignKey(r => r.JobId)
                  .OnDelete(DeleteBehavior.Restrict);
        });

        // JobScheduleState configuration
        modelBuilder.Entity<JobScheduleState>(entity =>
        {
            entity.ToTable("job_schedule_state");
            entity.HasKey(e => e.JobId);
            entity.Property(e => e.JobId).HasColumnName("job_id");
            entity.Property(e => e.LastScheduledAt).HasColumnName("last_scheduled_at").IsRequired();
            entity.Property(e => e.IsActive).HasColumnName("is_active").IsRequired();
            entity.Property(e => e.NextRunAt).HasColumnName("next_run_at");
            
            entity.Property(e => e.SchedulerId).HasColumnName("scheduler_id").HasMaxLength(100);
            entity.Property(e => e.Version).HasColumnName("version").IsRequired();
            entity.Property(e => e.CreatedAt).HasColumnName("created_at").IsRequired();
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at").IsRequired();
            
            entity.Property(e => e.LastReplicatedAt).HasColumnName("last_replicated_at");
            entity.Property(e => e.ReplicationVersion).HasColumnName("replication_version");

            // Indexes
            entity.HasIndex(e => e.IsActive).HasFilter("[is_active] = true").HasDatabaseName("idx_schedule_active");
            entity.HasIndex(e => e.NextRunAt).HasFilter("[next_run_at] IS NOT NULL").HasDatabaseName("idx_schedule_next_run");
        });

        // JobRun configuration
        modelBuilder.Entity<JobRun>(entity =>
        {
            entity.ToTable("job_run");
            entity.HasKey(e => new { e.RunId, e.ScheduledAt });
            entity.Property(e => e.RunId).HasColumnName("run_id");
            entity.Property(e => e.ScheduledAt).HasColumnName("scheduled_at").IsRequired();
            entity.Property(e => e.JobId).HasColumnName("job_id").IsRequired();
            
            entity.Property(e => e.Status).HasColumnName("status").HasConversion<string>().HasMaxLength(20).IsRequired();
            entity.Property(e => e.Attempt).HasColumnName("attempt").IsRequired();
            entity.Property(e => e.MaxRetry).HasColumnName("max_retry").IsRequired();
            entity.Property(e => e.QueueId).HasColumnName("queue_id").IsRequired();
            entity.Property(e => e.WorkerId).HasColumnName("worker_id").HasMaxLength(100);
            entity.Property(e => e.ServerId).HasColumnName("server_id").HasMaxLength(100);
            
            entity.Property(e => e.StartedAt).HasColumnName("started_at");
            entity.Property(e => e.FinishedAt).HasColumnName("finished_at");
            entity.Property(e => e.ExecutionDurationMs).HasColumnName("execution_duration_ms");
            
            entity.Property(e => e.OutputJson).HasColumnName("output_json");
            entity.Property(e => e.ErrorMessage).HasColumnName("error_message");
            entity.Property(e => e.Stdout).HasColumnName("stdout");
            entity.Property(e => e.Stderr).HasColumnName("stderr");
            
            entity.Property(e => e.RetryPolicyUsedJson).HasColumnName("retry_policy_used_json");
            entity.Property(e => e.NextRetryAt).HasColumnName("next_retry_at");
            
            entity.Property(e => e.Version).HasColumnName("version").IsRequired();
            entity.Property(e => e.CreatedAt).HasColumnName("created_at").IsRequired();
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at").IsRequired();
            
            entity.Property(e => e.LastReplicatedAt).HasColumnName("last_replicated_at");
            entity.Property(e => e.ReplicationVersion).HasColumnName("replication_version");

            // Indexes (will be created per partition)
            entity.HasIndex(e => new { e.Status, e.ScheduledAt }).HasDatabaseName("idx_run_status_time");
            entity.HasIndex(e => new { e.QueueId, e.Status }).HasDatabaseName("idx_run_queue");
            entity.HasIndex(e => e.JobId).HasDatabaseName("idx_run_job_id");
            entity.HasIndex(e => e.WorkerId).HasFilter("[worker_id] IS NOT NULL").HasDatabaseName("idx_run_worker");
        });

        // User configuration
        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("users");
            entity.HasKey(e => e.UserId);
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.Username).HasColumnName("username").HasMaxLength(255).IsRequired();
            entity.Property(e => e.Email).HasColumnName("email").HasMaxLength(255).IsRequired();
            entity.Property(e => e.PasswordHash).HasColumnName("password_hash").IsRequired();
            
            entity.Property(e => e.Role).HasColumnName("role").HasConversion<string>().HasMaxLength(20).IsRequired();
            entity.Property(e => e.IsActive).HasColumnName("is_active").IsRequired();
            
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at").IsRequired();
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at").IsRequired();
            entity.Property(e => e.LastLoginAt).HasColumnName("last_login_at");
            
            entity.Property(e => e.Version).HasColumnName("version").IsRequired();
            entity.Property(e => e.LastReplicatedAt).HasColumnName("last_replicated_at");
            entity.Property(e => e.ReplicationVersion).HasColumnName("replication_version");

            // Indexes
            entity.HasIndex(e => e.Email).IsUnique().HasDatabaseName("idx_users_email");
            entity.HasIndex(e => e.Username).IsUnique().HasDatabaseName("idx_users_username");
            entity.HasIndex(e => e.Role).HasFilter("[is_active] = true").HasDatabaseName("idx_users_role");
        });
    }
}
