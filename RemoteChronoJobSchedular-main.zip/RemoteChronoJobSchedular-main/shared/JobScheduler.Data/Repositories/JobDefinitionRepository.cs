using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Data.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace JobScheduler.Data.Repositories;

/// <summary>
/// Repository implementation for JobDefinition operations
/// </summary>
public class JobDefinitionRepository : IJobDefinitionRepository
{
    private readonly JobSchedulerDbContext _context;
    private readonly ILogger<JobDefinitionRepository> _logger;

    public JobDefinitionRepository(JobSchedulerDbContext context, ILogger<JobDefinitionRepository> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<JobDefinition?> GetByIdAsync(Guid jobId, CancellationToken ct = default)
    {
        return await _context.JobDefinitions
            .Include(j => j.ScheduleState)
            .Where(j => j.JobId == jobId && j.DeletedAt == null)
            .FirstOrDefaultAsync(ct);
    }

    public async Task<JobDefinition?> GetByIdIncludingDeletedAsync(Guid jobId, CancellationToken ct = default)
    {
        return await _context.JobDefinitions
            .Include(j => j.ScheduleState)
            .FirstOrDefaultAsync(j => j.JobId == jobId, ct);
    }

    public async Task<JobDefinition> CreateAsync(JobDefinition job, CancellationToken ct = default)
    {
        _context.JobDefinitions.Add(job);
        await _context.SaveChangesAsync(ct);
        
        _logger.LogDebug("Created job {JobId} for user {UserId}", job.JobId, job.UserId);
        
        return job;
    }

    public async Task<JobDefinition> UpdateAsync(JobDefinition job, int expectedVersion, CancellationToken ct = default)
    {
        var existing = await _context.JobDefinitions
            .FirstOrDefaultAsync(j => j.JobId == job.JobId, ct);

        if (existing == null)
        {
            throw new KeyNotFoundException($"Job with ID {job.JobId} not found");
        }

        // Optimistic locking check
        if (existing.Version != expectedVersion)
        {
            throw new InvalidOperationException(
                $"Version mismatch. Expected {expectedVersion}, got {existing.Version}. " +
                "The job was modified by another request.");
        }

        // Update fields
        existing.CronExpr = job.CronExpr;
        existing.ScriptContent = job.ScriptContent;
        existing.ArgsJson = job.ArgsJson;
        existing.RetryPolicyJson = job.RetryPolicyJson;
        existing.TimeoutSeconds = job.TimeoutSeconds;
        existing.Status = job.Status;
        existing.UpdatedBy = job.UpdatedBy;
        existing.UpdatedAt = DateTime.UtcNow;
        existing.Version++; // Increment version

        await _context.SaveChangesAsync(ct);
        
        _logger.LogDebug("Updated job {JobId}, new version: {Version}", existing.JobId, existing.Version);

        return existing;
    }

    public async Task<bool> DeleteAsync(Guid jobId, Guid deletedBy, CancellationToken ct = default)
    {
        var job = await _context.JobDefinitions
            .FirstOrDefaultAsync(j => j.JobId == jobId && j.DeletedAt == null, ct);

        if (job == null)
        {
            return false;
        }

        // Soft delete
        job.DeletedAt = DateTime.UtcNow;
        job.UpdatedBy = deletedBy;
        job.UpdatedAt = DateTime.UtcNow;
        job.Version++;

        // Also deactivate schedule state if exists
        var scheduleState = await _context.JobScheduleStates
            .FirstOrDefaultAsync(s => s.JobId == jobId, ct);
        
        if (scheduleState != null)
        {
            scheduleState.IsActive = false;
            scheduleState.UpdatedAt = DateTime.UtcNow;
        }

        await _context.SaveChangesAsync(ct);
        
        _logger.LogDebug("Deleted (soft) job {JobId}", jobId);

        return true;
    }

    public async Task<PagedResult<JobDefinition>> GetByUserIdAsync(
        Guid userId,
        int page,
        int pageSize,
        bool includeDeleted = false,
        CancellationToken ct = default)
    {
        var query = _context.JobDefinitions
            .Include(j => j.ScheduleState)
            .Where(j => j.UserId == userId);

        if (!includeDeleted)
        {
            query = query.Where(j => j.DeletedAt == null);
        }

        var totalCount = await query.CountAsync(ct);

        var items = await query
            .OrderByDescending(j => j.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return new PagedResult<JobDefinition>
        {
            Items = items,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        };
    }

    public async Task<List<JobDefinition>> GetActiveRecurringJobsAsync(CancellationToken ct = default)
    {
        return await _context.JobDefinitions
            .Include(j => j.ScheduleState)
            .Where(j => j.JobType == JobType.Recurring
                && j.Status == JobStatus.Active
                && j.DeletedAt == null
                && (j.ScheduleState == null || j.ScheduleState.IsActive))
            .ToListAsync(ct);
    }
}
