using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Enums;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Data.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace JobScheduler.Data.Repositories;

/// <summary>
/// Repository implementation for JobRun operations
/// </summary>
public class JobRunRepository : IJobRunRepository
{
    private readonly JobSchedulerDbContext _context;
    private readonly ILogger<JobRunRepository> _logger;

    public JobRunRepository(JobSchedulerDbContext context, ILogger<JobRunRepository> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<JobRun> CreateAsync(JobRun jobRun, CancellationToken ct = default)
    {
        _context.JobRuns.Add(jobRun);
        await _context.SaveChangesAsync(ct);
        return jobRun;
    }

    public async Task<JobRun?> GetByIdAsync(Guid runId, CancellationToken ct = default)
    {
        return await _context.JobRuns
            .Include(r => r.Job)
            .FirstOrDefaultAsync(r => r.RunId == runId, ct);
    }

    public async Task<List<JobRun>> GetPendingRunsAsync(int limit = 5000, CancellationToken ct = default)
    {
        var now = DateTime.UtcNow;
        return await _context.JobRuns
            .Include(r => r.Job)
            .Where(r => r.Status == JobRunStatus.Pending && r.ScheduledAt <= now)
            .OrderBy(r => r.ScheduledAt)
            .Take(limit)
            .ToListAsync(ct);
    }

    public async Task<List<JobRun>> GetRunningJobsAsync(CancellationToken ct = default)
    {
        return await _context.JobRuns
            .Where(r => r.Status == JobRunStatus.Running)
            .Select(r => new JobRun
            {
                RunId = r.RunId,
                Attempt = r.Attempt,
                MaxRetry = r.MaxRetry,
                RetryPolicyUsedJson = r.RetryPolicyUsedJson
            })
            .ToListAsync(ct);
    }

    public async Task<bool> TryClaimRunAsync(Guid runId, string workerId, CancellationToken ct = default)
    {
        // CAS update: Only update if status is QUEUED
        var run = await _context.JobRuns
            .FirstOrDefaultAsync(r => r.RunId == runId, ct);

        if (run == null || run.Status != JobRunStatus.Queued)
        {
            return false;
        }

        run.Status = JobRunStatus.Running;
        run.WorkerId = workerId;
        run.StartedAt = DateTime.UtcNow;
        run.UpdatedAt = DateTime.UtcNow;
        run.Version++;

        var rowsAffected = await _context.SaveChangesAsync(ct);
        return rowsAffected > 0;
    }

    public async Task<JobRun> UpdateRunStatusAsync(
        Guid runId,
        JobRunStatus status,
        string? outputJson = null,
        string? errorMessage = null,
        string? stdout = null,
        string? stderr = null,
        CancellationToken ct = default)
    {
        var run = await _context.JobRuns
            .FirstOrDefaultAsync(r => r.RunId == runId, ct)
            ?? throw new KeyNotFoundException($"Job run {runId} not found");

        run.Status = status;
        run.UpdatedAt = DateTime.UtcNow;
        run.Version++;

        if (status == JobRunStatus.Completed || status == JobRunStatus.Failed)
        {
            run.FinishedAt = DateTime.UtcNow;
            if (run.StartedAt.HasValue)
            {
                run.ExecutionDurationMs = (long)(run.FinishedAt.Value - run.StartedAt.Value).TotalMilliseconds;
            }
        }

        if (outputJson != null) run.OutputJson = outputJson;
        if (errorMessage != null) run.ErrorMessage = errorMessage;
        if (stdout != null) run.Stdout = stdout;
        if (stderr != null) run.Stderr = stderr;

        await _context.SaveChangesAsync(ct);
        return run;
    }

    public async Task<bool> MarkAsQueuedAsync(Guid runId, int queueId, CancellationToken ct = default)
    {
        var run = await _context.JobRuns
            .FirstOrDefaultAsync(r => r.RunId == runId, ct);

        if (run == null || run.Status != JobRunStatus.Pending && run.Status != JobRunStatus.RetryPending)
        {
            return false;
        }

        run.Status = JobRunStatus.Queued;
        run.QueueId = queueId;
        run.UpdatedAt = DateTime.UtcNow;
        run.Version++;

        await _context.SaveChangesAsync(ct);
        return true;
    }

    public async Task<bool> MarkAsRetryPendingAsync(Guid runId, DateTime nextRetryAt, CancellationToken ct = default)
    {
        var run = await _context.JobRuns
            .FirstOrDefaultAsync(r => r.RunId == runId, ct);

        if (run == null)
        {
            return false;
        }

        run.Status = JobRunStatus.RetryPending;
        run.NextRetryAt = nextRetryAt;
        run.Attempt++;
        run.UpdatedAt = DateTime.UtcNow;
        run.Version++;

        await _context.SaveChangesAsync(ct);
        return true;
    }

    public async Task<Dictionary<Guid, int>> GetPendingRunCountsByJobIdAsync(CancellationToken ct = default)
    {
        var counts = await _context.JobRuns
            .Where(r => r.Status == JobRunStatus.Pending)
            .GroupBy(r => r.JobId)
            .Select(g => new { JobId = g.Key, Count = g.Count() })
            .ToListAsync(ct);

        return counts.ToDictionary(x => x.JobId, x => x.Count);
    }

    public async Task BatchCreateAsync(List<JobRun> jobRuns, CancellationToken ct = default)
    {
        if (jobRuns == null || jobRuns.Count == 0)
        {
            return;
        }

        _context.JobRuns.AddRange(jobRuns);
        await _context.SaveChangesAsync(ct);
        
        _logger.LogDebug("Batch created {Count} job runs", jobRuns.Count);
    }

    public async Task<int> BatchMarkAsQueuedAsync(List<(Guid RunId, int QueueId)> updates, CancellationToken ct = default)
    {
        if (updates == null || updates.Count == 0)
        {
            return 0;
        }

        var runIds = updates.Select(u => u.RunId).ToList();
        var runs = await _context.JobRuns
            .Where(r => runIds.Contains(r.RunId) && 
                       (r.Status == JobRunStatus.Pending || r.Status == JobRunStatus.RetryPending))
            .ToListAsync(ct);

        var queueIdMap = updates.ToDictionary(u => u.RunId, u => u.QueueId);
        var now = DateTime.UtcNow;
        var updatedCount = 0;

        foreach (var run in runs)
        {
            if (queueIdMap.TryGetValue(run.RunId, out var queueId))
            {
                run.Status = JobRunStatus.Queued;
                run.QueueId = queueId;
                run.UpdatedAt = now;
                run.Version++;
                updatedCount++;
            }
        }

        if (updatedCount > 0)
        {
            await _context.SaveChangesAsync(ct);
            _logger.LogDebug("Batch updated {Count} runs to QUEUED status", updatedCount);
        }

        return updatedCount;
    }

    public async Task<PagedResult<JobRun>> GetRunsByJobIdAsync(Guid jobId, int page, int pageSize, CancellationToken ct = default)
    {
        var query = _context.JobRuns
            .Include(r => r.Job)
            .Where(r => r.JobId == jobId);

        var totalCount = await query.CountAsync(ct);

        var items = await query
            .OrderByDescending(r => r.ScheduledAt)
            .ThenByDescending(r => r.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);

        return new PagedResult<JobRun>
        {
            Items = items,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        };
    }

    public async Task<int> CancelPendingRunsForJobAsync(Guid jobId, CancellationToken ct = default)
    {
        // Cancel all PENDING and QUEUED runs (standard practice: let RUNNING complete)
        var runsToCancel = await _context.JobRuns
            .Where(r => r.JobId == jobId && 
                       (r.Status == JobRunStatus.Pending || r.Status == JobRunStatus.Queued))
            .ToListAsync(ct);

        if (runsToCancel.Count == 0)
        {
            return 0;
        }

        var now = DateTime.UtcNow;
        foreach (var run in runsToCancel)
        {
            run.Status = JobRunStatus.Cancelled;
            run.UpdatedAt = now;
            run.Version++;
        }

        await _context.SaveChangesAsync(ct);
        
        _logger.LogInformation("Cancelled {Count} pending/queued runs for job {JobId}", runsToCancel.Count, jobId);
        
        return runsToCancel.Count;
    }
}
