using JobScheduler.Contracts.Entities;
using JobScheduler.Contracts.Interfaces;
using JobScheduler.Data.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace JobScheduler.Data.Repositories;

/// <summary>
/// Repository implementation for JobScheduleState operations
/// </summary>
public class JobScheduleStateRepository : IJobScheduleStateRepository
{
    private readonly JobSchedulerDbContext _context;
    private readonly ILogger<JobScheduleStateRepository> _logger;

    public JobScheduleStateRepository(JobSchedulerDbContext context, ILogger<JobScheduleStateRepository> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<List<JobScheduleState>> GetActiveRecurringJobsAsync(CancellationToken ct = default)
    {
        return await _context.JobScheduleStates
            .Include(s => s.Job)
            .Where(s => s.IsActive && s.Job.DeletedAt == null && s.Job.Status == Contracts.Enums.JobStatus.Active)
            .ToListAsync(ct);
    }

    public async Task<JobScheduleState> GetOrCreateAsync(Guid jobId, CancellationToken ct = default)
    {
        var state = await _context.JobScheduleStates
            .FirstOrDefaultAsync(s => s.JobId == jobId, ct);

        if (state == null)
        {
            state = new JobScheduleState
            {
                JobId = jobId,
                LastScheduledAt = DateTime.UtcNow,
                IsActive = true,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            _context.JobScheduleStates.Add(state);
            await _context.SaveChangesAsync(ct);
        }

        return state;
    }

    public async Task UpdateLastScheduledAtAsync(Guid jobId, DateTime lastScheduledAt, DateTime? nextRunAt = null, CancellationToken ct = default)
    {
        var state = await _context.JobScheduleStates
            .FirstOrDefaultAsync(s => s.JobId == jobId, ct);

        if (state != null)
        {
            state.LastScheduledAt = lastScheduledAt;
            state.NextRunAt = nextRunAt;
            state.UpdatedAt = DateTime.UtcNow;
            state.Version++;
            await _context.SaveChangesAsync(ct);
        }
    }

    public async Task DeactivateAsync(Guid jobId, CancellationToken ct = default)
    {
        var state = await _context.JobScheduleStates
            .FirstOrDefaultAsync(s => s.JobId == jobId, ct);

        if (state != null)
        {
            state.IsActive = false;
            state.UpdatedAt = DateTime.UtcNow;
            state.Version++;
            await _context.SaveChangesAsync(ct);
        }
    }

    public async Task ActivateAsync(Guid jobId, CancellationToken ct = default)
    {
        var state = await _context.JobScheduleStates
            .FirstOrDefaultAsync(s => s.JobId == jobId, ct);

        if (state != null)
        {
            state.IsActive = true;
            state.UpdatedAt = DateTime.UtcNow;
            state.Version++;
            await _context.SaveChangesAsync(ct);
        }
    }

    public async Task BatchUpdateLastScheduledAtAsync(List<(Guid JobId, DateTime LastScheduledAt, DateTime? NextRunAt)> updates, CancellationToken ct = default)
    {
        if (updates == null || updates.Count == 0)
        {
            return;
        }

        var jobIds = updates.Select(u => u.JobId).ToList();
        var states = await _context.JobScheduleStates
            .Where(s => jobIds.Contains(s.JobId))
            .ToListAsync(ct);

        var updateMap = updates.ToDictionary(u => u.JobId, u => (u.LastScheduledAt, u.NextRunAt));
        var now = DateTime.UtcNow;

        foreach (var state in states)
        {
            if (updateMap.TryGetValue(state.JobId, out var update))
            {
                state.LastScheduledAt = update.LastScheduledAt;
                state.NextRunAt = update.NextRunAt;
                state.UpdatedAt = now;
                state.Version++;
            }
        }

        if (states.Count > 0)
        {
            await _context.SaveChangesAsync(ct);
            _logger.LogDebug("Batch updated {Count} schedule states", states.Count);
        }
    }
}
