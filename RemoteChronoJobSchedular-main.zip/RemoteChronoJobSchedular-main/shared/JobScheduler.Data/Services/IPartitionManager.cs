using System.Threading;
using System.Threading.Tasks;

namespace JobScheduler.Data.Services;

/// <summary>
/// Service for managing hourly partitions on job_run table
/// </summary>
public interface IPartitionManager
{
    /// <summary>
    /// Creates hourly partitions for the specified date range
    /// </summary>
    /// <param name="startDate">Start date (inclusive)</param>
    /// <param name="endDate">End date (exclusive)</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>Number of partitions created</returns>
    Task<int> CreateHourlyPartitionsAsync(DateTime startDate, DateTime endDate, CancellationToken ct = default);

    /// <summary>
    /// Creates partitions for the next N hours from now
    /// </summary>
    /// <param name="hoursAhead">Number of hours ahead to create partitions</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>Number of partitions created</returns>
    Task<int> EnsureFuturePartitionsAsync(int hoursAhead = 48, CancellationToken ct = default);

    /// <summary>
    /// Drops old partitions (older than specified days)
    /// </summary>
    /// <param name="daysToKeep">Number of days to keep</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>Number of partitions dropped</returns>
    Task<int> DropOldPartitionsAsync(int daysToKeep = 30, CancellationToken ct = default);

    /// <summary>
    /// Gets list of existing partitions
    /// </summary>
    /// <param name="ct">Cancellation token</param>
    /// <returns>List of partition names and their date ranges</returns>
    Task<List<(string PartitionName, DateTime StartDate, DateTime EndDate)>> GetExistingPartitionsAsync(CancellationToken ct = default);
}
