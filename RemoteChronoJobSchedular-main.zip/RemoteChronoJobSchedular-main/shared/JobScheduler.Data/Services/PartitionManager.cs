using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using JobScheduler.Data.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace JobScheduler.Data.Services;

/// <summary>
/// Manages hourly partitions for job_run table
/// Creates partitions automatically for future dates
/// </summary>
public class PartitionManager : IPartitionManager
{
    private readonly JobSchedulerDbContext _context;
    private readonly ILogger<PartitionManager> _logger;

    public PartitionManager(JobSchedulerDbContext context, ILogger<PartitionManager> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<int> CreateHourlyPartitionsAsync(DateTime startDate, DateTime endDate, CancellationToken ct = default)
    {
        var created = 0;
        var current = new DateTime(startDate.Year, startDate.Month, startDate.Day, startDate.Hour, 0, 0, DateTimeKind.Utc);

        while (current < endDate)
        {
            var partitionName = GetPartitionName(current);
            var nextHour = current.AddHours(1);
            var startTimestamp = ((DateTimeOffset)current).ToUnixTimeSeconds();
            var endTimestamp = ((DateTimeOffset)nextHour).ToUnixTimeSeconds();

            // Check if partition already exists
            var exists = await PartitionExistsAsync(partitionName, ct);
            if (!exists)
            {
                var sql = $@"
                    ALTER TABLE job_run
                    ADD PARTITION (
                        PARTITION {partitionName}
                        VALUES LESS THAN ({endTimestamp})
                    )";

                try
                {
                    await _context.Database.ExecuteSqlRawAsync(sql, ct);
                    _logger.LogInformation("Created partition {PartitionName} for {StartDate} to {EndDate}",
                        partitionName, current, nextHour);
                    created++;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to create partition {PartitionName}: {Error}",
                        partitionName, ex.Message);
                }
            }

            current = nextHour;
        }

        return created;
    }

    public async Task<int> EnsureFuturePartitionsAsync(int hoursAhead = 48, CancellationToken ct = default)
    {
        var now = DateTime.UtcNow;
        var startDate = new DateTime(now.Year, now.Month, now.Day, now.Hour, 0, 0, DateTimeKind.Utc);
        var endDate = startDate.AddHours(hoursAhead);

        return await CreateHourlyPartitionsAsync(startDate, endDate, ct);
    }

    public async Task<int> DropOldPartitionsAsync(int daysToKeep = 30, CancellationToken ct = default)
    {
        var cutoffDate = DateTime.UtcNow.AddDays(-daysToKeep);
        var cutoffTimestamp = ((DateTimeOffset)cutoffDate).ToUnixTimeSeconds();

        // Get all partitions
        var partitions = await GetExistingPartitionsAsync(ct);
        var dropped = 0;

        foreach (var (partitionName, startDate, endDate) in partitions)
        {
            if (endDate < cutoffDate)
            {
                try
                {
                    var sql = $"ALTER TABLE job_run DROP PARTITION {partitionName}";
                    await _context.Database.ExecuteSqlRawAsync(sql, ct);
                    _logger.LogInformation("Dropped old partition {PartitionName} (end date: {EndDate})",
                        partitionName, endDate);
                    dropped++;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Failed to drop partition {PartitionName}: {Error}",
                        partitionName, ex.Message);
                }
            }
        }

        return dropped;
    }

    public async Task<List<(string PartitionName, DateTime StartDate, DateTime EndDate)>> GetExistingPartitionsAsync(CancellationToken ct = default)
    {
        var results = new List<(string, DateTime, DateTime)>();

        await _context.Database.OpenConnectionAsync(ct);
        try
        {
            using var command = _context.Database.GetDbConnection().CreateCommand();
            command.CommandText = @"
                SELECT 
                    PARTITION_NAME,
                    PARTITION_DESCRIPTION
                FROM INFORMATION_SCHEMA.PARTITIONS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = 'job_run'
                AND PARTITION_NAME IS NOT NULL
                ORDER BY PARTITION_ORDINAL_POSITION";

            using var reader = await command.ExecuteReaderAsync(ct);
            while (await reader.ReadAsync(ct))
            {
                var partitionName = reader.GetString(0);
                var description = reader.GetString(1);

                if (long.TryParse(description, out var timestamp))
                {
                    var endDate = DateTimeOffset.FromUnixTimeSeconds(timestamp).UtcDateTime;
                    var startDate = endDate.AddHours(-1);
                    results.Add((partitionName, startDate, endDate));
                }
            }
        }
        finally
        {
            await _context.Database.CloseConnectionAsync();
        }

        return results;
    }

    private async Task<bool> PartitionExistsAsync(string partitionName, CancellationToken ct)
    {
        var partitions = await GetExistingPartitionsAsync(ct);
        return partitions.Any(p => p.PartitionName == partitionName);
    }

    private static string GetPartitionName(DateTime date)
    {
        // Format: p_20260124_10 (year_month_day_hour)
        return $"p_{date:yyyyMMdd}_{date:HH}";
    }
}
