using JobScheduler.Contracts.Interfaces;
using JobScheduler.Infrastructure.Redis;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;

namespace JobScheduler.Infrastructure.Queue;

/// <summary>
/// Redis-based queue service implementation
/// </summary>
public class RedisQueueService : IQueueService
{
    private readonly IDatabase _database;
    private readonly ILogger<RedisQueueService> _logger;
    private const string QueueKeyPrefix = "queue:";

    public RedisQueueService(RedisConnectionService redisConnection, ILogger<RedisQueueService> logger)
    {
        _database = redisConnection.Database;
        _logger = logger;
    }

    public async Task PushAsync(int queueId, Guid runId, CancellationToken ct = default)
    {
        var queueKey = $"{QueueKeyPrefix}{queueId}";
        await _database.ListLeftPushAsync(queueKey, runId.ToString());
        
        _logger.LogDebug("Pushed run {RunId} to queue {QueueId}", runId, queueId);
    }

    public async Task<Guid?> PopAsync(int queueId, int timeoutSeconds = 0, CancellationToken ct = default)
    {
        var queueKey = $"{QueueKeyPrefix}{queueId}";
        
        if (timeoutSeconds > 0)
        {
            // Blocking pop with timeout using BRPOP
            // Note: StackExchange.Redis doesn't have direct BRPOP, so we'll poll
            var endTime = DateTime.UtcNow.AddSeconds(timeoutSeconds);
            while (DateTime.UtcNow < endTime && !ct.IsCancellationRequested)
            {
                var result = await _database.ListRightPopAsync(queueKey);
                if (!result.IsNullOrEmpty)
                {
                    if (Guid.TryParse(result.ToString(), out var runId))
                    {
                        return runId;
                    }
                }
                
                // Wait a bit before retrying
                await Task.Delay(100, ct);
            }
            return null;
        }
        else
        {
            // Non-blocking pop (RPOP)
            var result = await _database.ListRightPopAsync(queueKey);
            if (result.IsNullOrEmpty)
            {
                return null;
            }
            
            if (Guid.TryParse(result.ToString(), out var runId))
            {
                return runId;
            }
        }
        
        return null;
    }

    /// <summary>
    /// Blocking pop from multiple queues (BLPOP equivalent)
    /// Returns the queue ID and run ID from whichever queue has a job first
    /// </summary>
    public async Task<(int QueueId, Guid RunId)?> PopFromMultipleQueuesAsync(int[] queueIds, int timeoutSeconds = 5, CancellationToken ct = default)
    {
        if (queueIds == null || queueIds.Length == 0)
        {
            return null;
        }

        var endTime = DateTime.UtcNow.AddSeconds(timeoutSeconds);
        
        // Try all queues in round-robin fashion until timeout
        while (DateTime.UtcNow < endTime && !ct.IsCancellationRequested)
        {
            // Check each queue (non-blocking)
            foreach (var queueId in queueIds)
            {
                var queueKey = $"{QueueKeyPrefix}{queueId}";
                var result = await _database.ListRightPopAsync(queueKey);
                
                if (!result.IsNullOrEmpty)
                {
                    if (Guid.TryParse(result.ToString(), out var runId))
                    {
                        _logger.LogDebug("Popped run {RunId} from queue {QueueId}", runId, queueId);
                        return (queueId, runId);
                    }
                }
            }
            
            // If no job found, wait a bit before retrying
            await Task.Delay(100, ct);
        }
        
        return null;
    }

    public async Task<long> GetLengthAsync(int queueId, CancellationToken ct = default)
    {
        var queueKey = $"{QueueKeyPrefix}{queueId}";
        return await _database.ListLengthAsync(queueKey);
    }
}
