using Microsoft.Extensions.Configuration;
using StackExchange.Redis;

namespace JobScheduler.Infrastructure.Redis;

/// <summary>
/// Redis connection service (singleton)
/// </summary>
public class RedisConnectionService : IDisposable
{
    private readonly IConnectionMultiplexer _connection;
    private readonly IDatabase _database;

    public RedisConnectionService(IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Redis") 
            ?? "localhost:6379";
        
        _connection = ConnectionMultiplexer.Connect(connectionString);
        _database = _connection.GetDatabase();
    }

    public IDatabase Database => _database;
    public IConnectionMultiplexer Connection => _connection;

    public void Dispose()
    {
        _connection?.Dispose();
    }
}
