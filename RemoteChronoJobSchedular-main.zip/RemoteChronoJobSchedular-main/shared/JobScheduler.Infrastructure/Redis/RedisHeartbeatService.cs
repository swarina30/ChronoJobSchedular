using JobScheduler.Contracts.Interfaces;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;

namespace JobScheduler.Infrastructure.Redis;

/// <summary>
/// Redis heartbeat service using ZSET for batch operations
/// </summary>
public class RedisHeartbeatService : IRedisHeartbeatService
{
    private readonly IDatabase _database;
    private readonly ILogger<RedisHeartbeatService> _logger;
    private const string HeartbeatZSetKey = "running_jobs";

    public RedisHeartbeatService(RedisConnectionService redisConnection, ILogger<RedisHeartbeatService> logger)
    {
        _database = redisConnection.Database;
        _logger = logger;
    }

    public async Task BatchUpdateHeartbeatAsync(List<Guid> runIds, CancellationToken ct = default)
    {
        if (runIds.Count == 0)
        {
            return;
        }

        var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var entries = new SortedSetEntry[runIds.Count];
        
        for (int i = 0; i < runIds.Count; i++)
        {
            entries[i] = new SortedSetEntry(runIds[i].ToString(), timestamp);
        }

        await _database.SortedSetAddAsync(HeartbeatZSetKey, entries);
        
        _logger.LogDebug("Updated heartbeat for {Count} run IDs", runIds.Count);
    }

    public async Task<HashSet<Guid>> GetActiveRunIdsAsync(CancellationToken ct = default)
    {
        var entries = await _database.SortedSetRangeByScoreWithScoresAsync(
            HeartbeatZSetKey, 
            double.NegativeInfinity, 
            double.PositiveInfinity);
        
        var activeRunIds = new HashSet<Guid>();
        
        foreach (var entry in entries)
        {
            if (Guid.TryParse(entry.Element.ToString(), out var runId))
            {
                activeRunIds.Add(runId);
            }
        }
        
        return activeRunIds;
    }

    public async Task CleanupStaleEntriesAsync(int staleThresholdSeconds = 60, CancellationToken ct = default)
    {
        var staleThreshold = DateTimeOffset.UtcNow.AddSeconds(-staleThresholdSeconds).ToUnixTimeSeconds();
        var removed = await _database.SortedSetRemoveRangeByScoreAsync(
            HeartbeatZSetKey, 
            double.NegativeInfinity, 
            staleThreshold);
        
        if (removed > 0)
        {
            _logger.LogInformation("Cleaned up {Count} stale heartbeat entries", removed);
        }
    }

    public async Task RemoveRunIdAsync(Guid runId, CancellationToken ct = default)
    {
        await _database.SortedSetRemoveAsync(HeartbeatZSetKey, runId.ToString());
        _logger.LogDebug("Removed heartbeat for run {RunId}", runId);
    }
}
