using NCrontab;

namespace JobScheduler.Infrastructure.Scheduling;

/// <summary>
/// Cron expression parser and scheduler
/// </summary>
public class CronExpressionParser
{
    /// <summary>
    /// Get next scheduled time from cron expression
    /// </summary>
    /// <param name="cronExpr">Cron expression (e.g., "0 */5 * * * *" for every 5 minutes)</param>
    /// <param name="fromTime">Base time to calculate from</param>
    /// <returns>Next scheduled time</returns>
    public static DateTime GetNextScheduledTime(string cronExpr, DateTime fromTime)
    {
        try
        {
            var schedule = CrontabSchedule.Parse(cronExpr);
            return schedule.GetNextOccurrence(fromTime);
        }
        catch (Exception ex)
        {
            throw new ArgumentException($"Invalid cron expression: {cronExpr}", nameof(cronExpr), ex);
        }
    }
    
    /// <summary>
    /// Get next N scheduled times
    /// </summary>
    public static List<DateTime> GetNextScheduledTimes(string cronExpr, DateTime fromTime, int count)
    {
        var schedule = CrontabSchedule.Parse(cronExpr);
        var times = new List<DateTime>();
        var currentTime = fromTime;
        
        for (int i = 0; i < count; i++)
        {
            currentTime = schedule.GetNextOccurrence(currentTime);
            times.Add(currentTime);
        }
        
        return times;
    }
    
    /// <summary>
    /// Validate cron expression
    /// </summary>
    public static bool IsValid(string cronExpr)
    {
        try
        {
            CrontabSchedule.Parse(cronExpr);
            return true;
        }
        catch
        {
            return false;
        }
    }
}
