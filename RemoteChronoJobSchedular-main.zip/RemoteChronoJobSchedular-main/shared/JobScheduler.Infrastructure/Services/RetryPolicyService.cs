using JobScheduler.Contracts.Interfaces;
using JobScheduler.Contracts.Models;
using JobScheduler.Infrastructure.Strategies;

namespace JobScheduler.Infrastructure.Services;

/// <summary>
/// Factory service for retry strategies (Strategy pattern)
/// </summary>
public class RetryPolicyService
{
    private readonly Dictionary<string, IRetryStrategy> _strategies;

    public RetryPolicyService()
    {
        _strategies = new Dictionary<string, IRetryStrategy>(StringComparer.OrdinalIgnoreCase)
        {
            { "ExponentialBackoff", new ExponentialBackoffStrategy() },
            { "Linear", new LinearBackoffStrategy() },
            { "Fixed", new FixedBackoffStrategy() }
        };
    }

    /// <summary>
    /// Get retry strategy by name
    /// </summary>
    public IRetryStrategy GetStrategy(string strategyName)
    {
        if (!_strategies.TryGetValue(strategyName, out var strategy))
        {
            // Default to exponential backoff if strategy not found
            return _strategies["ExponentialBackoff"];
        }

        return strategy;
    }

    /// <summary>
    /// Calculate delay for retry attempt
    /// </summary>
    public TimeSpan CalculateDelay(int attempt, RetryPolicy policy)
    {
        var strategy = GetStrategy(policy.Strategy);
        return strategy.CalculateDelay(attempt, policy);
    }

    /// <summary>
    /// Check if retry should be attempted
    /// </summary>
    public bool ShouldRetry(int attempt, RetryPolicy policy, Exception? exception = null)
    {
        var strategy = GetStrategy(policy.Strategy);
        return strategy.ShouldRetry(attempt, policy.MaxAttempts, exception);
    }
}
