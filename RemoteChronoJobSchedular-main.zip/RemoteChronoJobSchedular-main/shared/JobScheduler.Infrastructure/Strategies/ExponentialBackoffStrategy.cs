using JobScheduler.Contracts.Interfaces;
using JobScheduler.Contracts.Models;

namespace JobScheduler.Infrastructure.Strategies;

/// <summary>
/// Exponential backoff retry strategy: delay = base * (multiplier ^ attempt)
/// </summary>
public class ExponentialBackoffStrategy : IRetryStrategy
{
    public TimeSpan CalculateDelay(int attempt, RetryPolicy policy)
    {
        var baseDelay = TimeSpan.FromSeconds(policy.InitialDelaySeconds);
        var multiplier = policy.Multiplier;
        
        // Calculate: baseDelay * (multiplier ^ (attempt - 1))
        var delaySeconds = policy.InitialDelaySeconds * Math.Pow(multiplier, attempt - 1);
        
        // Cap at max delay
        var maxDelaySeconds = policy.MaxDelaySeconds;
        delaySeconds = Math.Min(delaySeconds, maxDelaySeconds);
        
        return TimeSpan.FromSeconds(delaySeconds);
    }

    public bool ShouldRetry(int attempt, int maxAttempts, Exception? exception = null)
    {
        return attempt < maxAttempts;
    }
}
