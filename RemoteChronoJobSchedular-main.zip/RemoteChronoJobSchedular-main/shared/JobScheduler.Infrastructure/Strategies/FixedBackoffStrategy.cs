using JobScheduler.Contracts.Interfaces;
using JobScheduler.Contracts.Models;

namespace JobScheduler.Infrastructure.Strategies;

/// <summary>
/// Fixed backoff retry strategy: delay = constant (initialDelaySeconds)
/// </summary>
public class FixedBackoffStrategy : IRetryStrategy
{
    public TimeSpan CalculateDelay(int attempt, RetryPolicy policy)
    {
        return TimeSpan.FromSeconds(policy.InitialDelaySeconds);
    }

    public bool ShouldRetry(int attempt, int maxAttempts, Exception? exception = null)
    {
        return attempt < maxAttempts;
    }
}
