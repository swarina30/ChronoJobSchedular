using JobScheduler.Contracts.Interfaces;
using JobScheduler.Contracts.Models;

namespace JobScheduler.Infrastructure.Strategies;

/// <summary>
/// Linear backoff retry strategy: delay = base * attempt
/// </summary>
public class LinearBackoffStrategy : IRetryStrategy
{
    public TimeSpan CalculateDelay(int attempt, RetryPolicy policy)
    {
        // Calculate: baseDelay * attempt
        var delaySeconds = policy.InitialDelaySeconds * attempt;
        
        // Cap at max delay
        var maxDelaySeconds = policy.MaxDelaySeconds;
        delaySeconds = Math.Min(delaySeconds, maxDelaySeconds);
        
        return TimeSpan.FromSeconds(delaySeconds);
    }

    public bool ShouldRetry(int attempt, int maxAttempts, Exception? exception = null)
    {
        return attempt < maxAttempts;
    }
}
