#!/bin/bash

# Full Flow Test Script for Distributed Job Scheduler
# This script tests the complete workflow: API -> Scheduler -> Worker

set -e

echo "=========================================="
echo "Full Flow Test - Distributed Job Scheduler"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
API_URL="http://localhost:5136"
MYSQL_HOST="localhost"
MYSQL_PORT="3306"
MYSQL_USER="root"
MYSQL_PASSWORD="root"
MYSQL_DB="job_scheduler_dev"
REDIS_HOST="localhost"
REDIS_PORT="6379"

# Test functions
test_mysql() {
    echo -n "Testing MySQL connection... "
    if docker exec job-scheduler-mysql mysql -h localhost -u $MYSQL_USER -p$MYSQL_PASSWORD -e "SELECT 1" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC}"
        return 0
    elif mysql -h $MYSQL_HOST -P $MYSQL_PORT -u $MYSQL_USER -p$MYSQL_PASSWORD -e "SELECT 1" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC}"
        return 0
    else
        echo -e "${RED}✗${NC}"
        return 1
    fi
}

test_redis() {
    echo -n "Testing Redis connection... "
    if docker exec job-scheduler-redis redis-cli ping > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC}"
        return 0
    elif redis-cli -h $REDIS_HOST -p $REDIS_PORT ping > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC}"
        return 0
    else
        echo -e "${RED}✗${NC}"
        return 1
    fi
}

test_api() {
    echo -n "Testing API health... "
    if curl -s -f "$API_URL/swagger/v1/swagger.json" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC}"
        return 0
    else
        echo -e "${RED}✗${NC}"
        return 1
    fi
}

# Step 1: Check Prerequisites
echo "Step 1: Checking Prerequisites"
echo "----------------------------"
test_mysql || { echo -e "${RED}MySQL is not accessible. Please start MySQL first.${NC}"; exit 1; }
test_redis || { echo -e "${RED}Redis is not accessible. Please start Redis first.${NC}"; exit 1; }
test_api || { echo -e "${RED}API is not running. Please start Job.Api service.${NC}"; exit 1; }
echo ""

# Step 2: Login and Get Token
echo "Step 2: Authentication"
echo "----------------------------"
echo -n "Logging in... "
LOGIN_RESPONSE=$(curl -s -X POST "$API_URL/api/auth/login" \
    -H "Content-Type: application/json" \
    -d '{
        "email": "test@example.com",
        "password": "password",
        "userId": "00000000-0000-0000-0000-000000000001",
        "role": "User"
    }')

TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
    echo -e "${RED}✗ Failed to get token${NC}"
    echo "Response: $LOGIN_RESPONSE"
    exit 1
fi
echo -e "${GREEN}✓${NC} Token obtained (${#TOKEN} chars)"
echo ""

# Step 3: Create One-Time Job
echo "Step 3: Creating One-Time Job"
echo "----------------------------"
echo -n "Creating job... "
JOB_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
        "jobType": "OneTime",
        "scriptContent": "print(\"Hello from One-Time Job!\")",
        "timeoutSeconds": 3600
    }')

JOB_ID=$(echo $JOB_RESPONSE | grep -o '"jobId":"[^"]*' | cut -d'"' -f4)

if [ -z "$JOB_ID" ]; then
    echo -e "${RED}✗ Failed to create job${NC}"
    echo "Response: $JOB_RESPONSE"
    exit 1
fi
echo -e "${GREEN}✓${NC} Job created: $JOB_ID"
echo ""

# Step 4: Create Recurring Job
echo "Step 4: Creating Recurring Job"
echo "----------------------------"
echo -n "Creating recurring job... "
RECURRING_JOB_RESPONSE=$(curl -s -X POST "$API_URL/api/jobs" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{
        "jobType": "Recurring",
        "cronExpr": "0 */5 * * * *",
        "scriptContent": "print(\"Hello from Recurring Job!\")",
        "timeoutSeconds": 3600
    }')

RECURRING_JOB_ID=$(echo $RECURRING_JOB_RESPONSE | grep -o '"jobId":"[^"]*' | cut -d'"' -f4)

if [ -z "$RECURRING_JOB_ID" ]; then
    echo -e "${RED}✗ Failed to create recurring job${NC}"
    echo "Response: $RECURRING_JOB_RESPONSE"
    exit 1
fi
echo -e "${GREEN}✓${NC} Recurring job created: $RECURRING_JOB_ID"
echo ""

# Step 5: Verify Database
echo "Step 5: Verifying Database"
echo "----------------------------"
echo -n "Checking job_definition table... "
if docker exec job-scheduler-mysql mysql -h localhost -u $MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DB -e "SELECT COUNT(*) FROM job_definition" > /dev/null 2>&1; then
    JOB_COUNT=$(docker exec job-scheduler-mysql mysql -h localhost -u $MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DB -N -e "SELECT COUNT(*) FROM job_definition" 2>/dev/null || echo "0")
    echo -e "${GREEN}✓${NC} Found $JOB_COUNT job(s)"
else
    echo -e "${YELLOW}⚠${NC} Could not verify (may need manual check)"
fi
echo ""

# Step 6: Wait for Scheduler to Process
echo "Step 6: Waiting for Scheduler Processing"
echo "----------------------------"
echo "Waiting 5 seconds for scheduler to process jobs..."
sleep 5
echo ""

# Step 7: Check Redis Queues
echo "Step 7: Checking Redis Queues"
echo "----------------------------"
if docker exec job-scheduler-redis redis-cli LLEN queue:0 > /dev/null 2>&1; then
    QUEUE_0_LEN=$(docker exec job-scheduler-redis redis-cli LLEN queue:0 2>/dev/null || echo "0")
    QUEUE_1_LEN=$(docker exec job-scheduler-redis redis-cli LLEN queue:1 2>/dev/null || echo "0")
    echo "Queue 0 length: $QUEUE_0_LEN"
    echo "Queue 1 length: $QUEUE_1_LEN"
else
    echo -e "${YELLOW}⚠${NC} Could not check queues (may need manual check)"
fi
echo ""

# Step 8: Check Heartbeats
echo "Step 8: Checking Redis Heartbeats"
echo "----------------------------"
if docker exec job-scheduler-redis redis-cli ZRANGE running_jobs 0 -1 WITHSCORES > /dev/null 2>&1; then
    HEARTBEAT_COUNT=$(docker exec job-scheduler-redis redis-cli ZCARD running_jobs 2>/dev/null || echo "0")
    echo "Active heartbeats: $HEARTBEAT_COUNT"
    if [ "$HEARTBEAT_COUNT" -gt 0 ]; then
        echo "Sample heartbeats:"
        docker exec job-scheduler-redis redis-cli ZRANGE running_jobs 0 4 WITHSCORES 2>/dev/null || echo "  (none)"
    fi
else
    echo -e "${YELLOW}⚠${NC} Could not check heartbeats (may need manual check)"
fi
echo ""

# Step 9: Check Job Runs
echo "Step 9: Checking Job Runs"
echo "----------------------------"
if docker exec job-scheduler-mysql mysql -h localhost -u $MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DB -e "SELECT COUNT(*) FROM job_run" > /dev/null 2>&1; then
    RUN_COUNT=$(docker exec job-scheduler-mysql mysql -h localhost -u $MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DB -N -e "SELECT COUNT(*) FROM job_run" 2>/dev/null || echo "0")
    COMPLETED_COUNT=$(docker exec job-scheduler-mysql mysql -h localhost -u $MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DB -N -e "SELECT COUNT(*) FROM job_run WHERE status = 'COMPLETED'" 2>/dev/null || echo "0")
    RUNNING_COUNT=$(docker exec job-scheduler-mysql mysql -h localhost -u $MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DB -N -e "SELECT COUNT(*) FROM job_run WHERE status = 'RUNNING'" 2>/dev/null || echo "0")
    QUEUED_COUNT=$(docker exec job-scheduler-mysql mysql -h localhost -u $MYSQL_USER -p$MYSQL_PASSWORD $MYSQL_DB -N -e "SELECT COUNT(*) FROM job_run WHERE status = 'QUEUED'" 2>/dev/null || echo "0")
    
    echo "Total runs: $RUN_COUNT"
    echo "  - Completed: $COMPLETED_COUNT"
    echo "  - Running: $RUNNING_COUNT"
    echo "  - Queued: $QUEUED_COUNT"
else
    echo -e "${YELLOW}⚠${NC} Could not check job runs (may need manual check)"
fi
echo ""

# Summary
echo "=========================================="
echo "Test Summary"
echo "=========================================="
echo -e "${GREEN}✓${NC} Prerequisites checked"
echo -e "${GREEN}✓${NC} Authentication successful"
echo -e "${GREEN}✓${NC} Jobs created"
echo -e "${GREEN}✓${NC} Database verified"
echo ""
echo "Next steps:"
echo "1. Check Scheduler logs for Loop A (Future Run Creation)"
echo "2. Check Scheduler logs for Loop B (Dispatch)"
echo "3. Check Worker logs for job execution"
echo "4. Check Scheduler logs for Loop C (Heartbeat Monitor)"
echo ""
echo "Full flow test completed!"
